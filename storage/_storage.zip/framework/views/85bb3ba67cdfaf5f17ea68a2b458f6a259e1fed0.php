


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h3 class="fw-bold text-primary mb-1">Order Entry</h3>
    <p class="text-muted mb-4">Create prescriptions and order services for patients</p>

    <?php if($recentAdmissions->count()): ?>
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            Recently admitted &mdash; <?php echo e(now()->format('M d')); ?>

        </div>
        <div class="card-body p-0">
            <table class="table mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Name</th>
                        <th>Room</th>
                        <th class="text-end pe-4">Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $recentAdmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($admit->patient->patient_first_name); ?>

                                <?php echo e($admit->patient->patient_last_name); ?>

                            </td>
                            <td><?php echo e($admit->room?->room_number ?? '—'); ?></td>
                            <td class="text-end pe-4">
                                <?php echo e($admit->admission_date->format('h:i A')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col">
                <input
  type="text"
  name="q"
  class="form-control"
  placeholder="Search by Name or MRN"
  value="<?php echo e($q); ?>"
>

                </div>
                <div class="col-auto">
                    <button class="btn btn-primary">Search</button>
                </div>
            </form>
        </div>
    </div>

    <table class="table table-hover">
        <thead class="table-light">
            <tr>
                <th>Name</th>
                <th>Sex</th>
                <th>Room</th>
                <th class="text-center">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php echo e($patient->patient_first_name); ?>

                        <?php echo e($patient->patient_last_name); ?>

                    </td>
                    <td><?php echo e($patient->sex ?? '—'); ?></td>
                    <td>
                        <?php echo e($patient->admissionDetail?->room?->room_number ?? '—'); ?>

                    </td>
                    <td class="text-center">
                        <a 
                          href="<?php echo e(route('doctor.order', $patient)); ?>" 
                          class="btn btn-outline-secondary btn-sm"
                        >
                            <i class="fas fa-file-alt me-1"></i> Details
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-muted">
                        No patients found.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-end mt-3">
        <?php echo e($patients->withQueryString()->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/doctor/dashboard.blade.php ENDPATH**/ ?>