


<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Manual Charges</h4>
    <a href="<?php echo e(route('billing.charges.create')); ?>" class="btn btn-primary">
      <i class="fa-solid fa-plus me-1"></i> New Charge
    </a>
  </div>

  <?php if($items->isEmpty()): ?>
    <div class="alert alert-info">No manual charges have been posted yet.</div>
  <?php else: ?>
    <table class="table table-striped align-middle">
      <thead>
        <tr>
          <th>#</th>
          <th>Patient</th>
          <th>Service</th>
          <th>Qty</th>
          <th class="text-end">Amount</th>
          <th>Date</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($item->billing_item_id); ?></td>
            <td>
              <?php echo e(optional($item->bill->patient)->patient_first_name); ?>

              <?php echo e(optional($item->bill->patient)->patient_last_name); ?>

            </td>
            <td><?php echo e(optional($item->service)->service_name); ?></td>
            <td><?php echo e($item->quantity); ?></td>
            <td class="text-end">₱<?php echo e(number_format($item->amount,2)); ?></td>
            <td><?php echo e(optional($item->bill)->billing_date?->format('Y-m-d')); ?></td>
            <td class="text-end">
              <a href="<?php echo e(route('billing.charges.show', $item->billing_item_id)); ?>"
                 class="btn btn-sm btn-outline-secondary me-1">
                View
              </a>
              <a href="<?php echo e(route('billing.charges.edit', $item->billing_item_id)); ?>"
                 class="btn btn-sm btn-outline-primary me-1">
                Edit
              </a>
              <a href="<?php echo e(route('billing.charges.audit', $item->billing_item_id)); ?>"
                 class="btn btn-sm btn-outline-info me-1">
                Audit
              </a>
              <form method="POST"
                    action="<?php echo e(route('billing.charges.destroy', $item->billing_item_id)); ?>"
                    class="d-inline"
                    onsubmit="return confirm('Delete this charge?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-outline-danger">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <?php echo e($items->links()); ?>

  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.billing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/billing/charges/index.blade.php ENDPATH**/ ?>