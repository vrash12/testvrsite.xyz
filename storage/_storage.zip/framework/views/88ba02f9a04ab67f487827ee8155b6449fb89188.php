


<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
  <h2 class="mb-4">Patient Admission Management</h2>
  <p class="text-muted mb-5">Manage patient admissions and doctor assignments</p>

  
  <div class="row g-4 mb-5">
    <?php $__currentLoopData = [
      ['label'=>'Total Patients',   'value'=>$totalPatients,  'icon'=>'fa-users'],
      ['label'=>'New Admissions',   'value'=>$newAdmissions,  'icon'=>'fa-user-plus'],
      ['label'=>'Available Beds',   'value'=>$availableBeds,  'icon'=>'fa-bed'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body d-flex align-items-center">
          <div class="me-3">
            <i class="fas <?php echo e($card['icon']); ?> fa-2x text-primary"></i>
          </div>
          <div>
            <div class="text-muted"><?php echo e($card['label']); ?></div>
            <h3 class="mb-0"><?php echo e($card['value']); ?></h3>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <div class="input-group w-50">
        <input type="text" class="form-control" placeholder="Search by Name or MRN">
        <span class="input-group-text"><i class="fas fa-search"></i></span>
      </div>
      <a href="<?php echo e(route('admission.patients.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus me-1"></i> Admit new patient
      </a>
    </div>
    <div class="table-responsive">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>Date</th>
            <th>Patient ID</th>
            <th>Patient</th>
            <th>Room/Ward</th>
            <th>Assigned Doctor</th>
            <th>Diagnosis</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $recentAdmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($adm->admission_date->format('Y-m-d')); ?></td>
              <td><?php echo e(optional($adm->patient)->patient_id ?? '–'); ?></td>
              <td><?php echo e(optional($adm->patient)->patient_first_name); ?> <?php echo e(optional($adm->patient)->patient_last_name); ?></td>
              <td>
  <?php echo e(optional($adm->room)->room_number ?? '–'); ?>

</td>

              <td><?php echo e($adm->doctor->doctor_name); ?></td>
              <td>
  <?php echo e(optional(optional($adm->patient)->medicalDetail)->primary_reason ?? '—'); ?>

</td>

<td>
  <?php if($adm->patient): ?>
    <a href="<?php echo e(route('admission.patients.show', $adm->patient)); ?>"
       class="btn btn-sm btn-outline-secondary">
      <i class="fas fa-file-alt"></i> Details
    </a>
  <?php else: ?>
    &mdash;
  <?php endif; ?>
</td>

            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7" class="text-center">No recent admissions.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/admission/dashboard.blade.php ENDPATH**/ ?>