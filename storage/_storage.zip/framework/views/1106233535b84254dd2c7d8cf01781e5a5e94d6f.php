


<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

  
  <?php if(session('generatedEmail') && session('plainPassword')): ?>
    <div class="alert alert-success">
      <p><strong>Credentials:</strong></p>
      <p>Email: <code><?php echo e(session('generatedEmail')); ?></code></p>
      <p>Password: <code><?php echo e(session('plainPassword')); ?></code></p>
    </div>
  <?php endif; ?>

  
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="text-primary">
      Patient Details:
      <?php echo e($patient->patient_first_name); ?> <?php echo e($patient->patient_last_name); ?>

    </h2>
   <a href="<?php echo e(route('admission.patients.index')); ?>" class="btn btn-secondary">
      ← Back to Patients
    </a>
  </div>

  
  <div class="card mb-4">
    <div class="card-header">Personal Information</div>
    <div class="card-body">
      <p><strong>Email:</strong> <?php echo e($patient->email); ?></p>
      <p><strong>Password:</strong>
        <?php if(session('plainPassword')): ?>
          <code><?php echo e(session('plainPassword')); ?></code>
        <?php else: ?>
          <span class="text-muted">••••••••</span>
        <?php endif; ?>
      </p>
      <p><strong>Phone:</strong> <?php echo e($patient->phone_number ?? '—'); ?></p>
      <p><strong>Birthday:</strong> <?php echo e($patient->patient_birthday?->format('M d, Y') ?? '—'); ?></p>
      <p><strong>Civil Status:</strong> <?php echo e($patient->civil_status ?? '—'); ?></p>
      <p><strong>Address:</strong> <?php echo e($patient->address ?? '—'); ?></p>
       <p><strong>Sex:</strong> <?php echo e($patient->sex ?? '—'); ?></p>
    </div>
  </div>

  
  <div class="card mb-4">
    <div class="card-header">Medical Details</div>
    <div class="card-body">
      <p><strong>Primary Reason:</strong> <?php echo e($patient->medicalDetail?->primary_reason ?? '—'); ?></p>
      <p><strong>Vitals:</strong>
        Weight <?php echo e($patient->medicalDetail?->weight ?? '—'); ?> kg,
        Height <?php echo e($patient->medicalDetail?->height ?? '—'); ?> cm,
        Temp <?php echo e($patient->medicalDetail?->temperature ?? '—'); ?>°F,
        BP <?php echo e($patient->medicalDetail?->blood_pressure ?? '—'); ?>,
        HR <?php echo e($patient->medicalDetail?->heart_rate ?? '—'); ?> bpm
      </p>

      <?php
       $history = $patient->medicalDetail?->medical_history;
  if (is_string($history)) {
      $history = json_decode($history, true) ?: [];
  } elseif (! is_array($history)) {
      $history = [];
  }

  $allergies = $patient->medicalDetail?->allergies;
  if (is_string($allergies)) {
      $allergies = json_decode($allergies, true) ?: [];
  } elseif (! is_array($allergies)) {
      $allergies = [];
  }
      ?>

      <p><strong>Medical History:</strong></p>
      <?php if(empty($history) || (collect($history)->filter(fn($v,$k)=>$k!=='others' && $v)->isEmpty() && empty($history['others']))): ?>
        <p>—</p>
      <?php else: ?>
        <ul>
          <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key === 'others' || !$value) continue; ?>
            <li><?php echo e(ucwords(str_replace('_',' ',$key))); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if(!empty($history['others'])): ?>
            <li>Other: <?php echo e($history['others']); ?></li>
          <?php endif; ?>
        </ul>
      <?php endif; ?>

      <p><strong>Allergies:</strong></p>
      <?php if(empty($allergies) || (collect($allergies)->filter(fn($v,$k)=>$k!=='others' && $v)->isEmpty() && empty($allergies['others']))): ?>
        <p>—</p>
      <?php else: ?>
        <ul>
          <?php $__currentLoopData = $allergies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key === 'others' || !$value) continue; ?>
            <li>
              <?php echo e($key==='none'
                 ? 'No Known Allergies'
                 : ucwords(str_replace('_',' ',$key))); ?>

            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if(!empty($allergies['others'])): ?>
            <li>Other: <?php echo e($allergies['others']); ?></li>
          <?php endif; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>

  
  <div class="card mb-4">
    <div class="card-header">Admission Details</div>
    <div class="card-body">
      <p><strong>Date:</strong> <?php echo e($patient->admissionDetail?->admission_date?->format('M d, Y') ?? '—'); ?></p>
      <p><strong>Type:</strong> <?php echo e($patient->admissionDetail?->admission_type ?? '—'); ?></p>
      <p><strong>Source:</strong> <?php echo e($patient->admissionDetail?->admission_source ?? '—'); ?></p>
      <p><strong>Department:</strong> <?php echo e($patient->admissionDetail?->department?->department_name ?? '—'); ?></p>
      <p><strong>Doctor:</strong> <?php echo e($patient->admissionDetail?->doctor?->doctor_name ?? '—'); ?></p>
      <p><strong>Room/Bed:</strong>
         <?php echo e($patient->admissionDetail?->room_number ?? '—'); ?> /
         <?php echo e($patient->admissionDetail?->bed_number ?? '—'); ?>

      </p>
      <p><strong>Notes:</strong> <?php echo e($patient->admissionDetail?->admission_notes ?? '—'); ?></p>
    </div>
  </div>

  
  <div class="card mb-4">
    <div class="card-header">Billing Information</div>
    <div class="card-body">
      <p><strong>Payment Method:</strong> <?php echo e($patient->billingInformation?->paymentMethod?->name ?? '—'); ?></p>
      <p><strong>Insurance:</strong> <?php echo e($patient->billingInformation?->insuranceProvider?->name ?? '—'); ?></p>
      <p><strong>Policy Number:</strong> <?php echo e($patient->billingInformation?->policy_number ?? '—'); ?></p>

      <hr>
      <h5>Bills & Items</h5>
      <?php if($patient->bills->isEmpty()): ?>
        <p>— No bills found.</p>
      <?php else: ?>
        <?php $__currentLoopData = $patient->bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="mb-3">
            <strong>
              Bill #<?php echo e($bill->billing_id); ?>

              (<?php echo e($bill->billing_date?->format('M d, Y') ?? '—'); ?>)
            </strong>
            <?php if($bill->items->isEmpty()): ?>
              <p class="ms-3">— No items.</p>
            <?php else: ?>
              <ul class="list-unstyled ms-3">
                <?php $__currentLoopData = $bill->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    • ₱<?php echo e(number_format($item->amount,2)); ?>

                      on <?php echo e($item->billing_date?->format('M d, Y') ?? '—'); ?>

                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/patients/show.blade.php ENDPATH**/ ?>