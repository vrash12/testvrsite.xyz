



<?php $__env->startSection('content'); ?>

    <div class="container-fluid h-100 border p-4 d-flex flex-column" style="background-color: #fafafa;">
        
        
        <div>
            <h1 class="hdng">Summary</h1>
            <p>Kindly review the summary details below before approval</p>
        </div>
        
        
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <i class="fa-solid fa-hashtag me-2"></i><strong>TRANSACTION NO</strong>
                    </div>
                    <div class="card-body">
                       <?php echo e($charge->created_at->format('M d, Y')); ?>


                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <i class="fa-solid fa-bed me-2"></i><strong>PATIENT</strong>
                    </div>
                    <div class="card-body">
                        <?php echo e($charge->patient->patient_first_name); ?>

                        <?php echo e($charge->patient->patient_last_name); ?>

                    </div>
                </div>
            </div>
      <div class="col-md-4">
  <div class="card">
    <div class="card-header">
      <i class="fa-solid fa-user-doctor me-2"></i><strong>DOCTOR ASSIGNED</strong>
    </div>
    <div class="card-body">
      <?php echo e(optional(optional($charge->patient->admissionDetail)->doctor)->doctor_name ?? '—'); ?>

    </div>
  </div>
</div>

        </div>

    
<div class="card mb-4">
  <div class="card-header">
    <i class="fa-solid fa-receipt me-2"></i><strong>LIST OF CHARGES</strong>
  </div>
  <div class="card-body p-0">
    <form method="POST" action="<?php echo e(route('supplies.checkout', $charge->id)); ?>" id="form">
      <?php echo csrf_field(); ?>
      <table class="table mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>ITEM NAME</th>
            <th>QUANTITY</th>
            <th>UNIT PRICE</th>
            <th>SUBTOTAL</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td><?php echo e($charge->service->service_name); ?></td>
            <td><?php echo e($charge->quantity); ?></td>
            <td>₱<?php echo e(number_format($charge->unit_price,2)); ?></td>
            <td>₱<?php echo e(number_format($charge->total,2)); ?></td>
          </tr>
          <tr>
            <td colspan="5" class="text-center fw-bold text-muted">** Nothing Follows **</td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <th colspan="4" class="text-end">Total</th>
            <th>₱<?php echo e(number_format($charge->total,2)); ?></th>
          </tr>
        </tfoot>
      </table>
    </form>
  </div>
</div>

        
        <?php if($charge->notes): ?>
            <div class="card mb-4">
            <div class="card-header">Notes</div>
            <div class="card-body">
                <p><?php echo e($charge->notes); ?></p>
            </div>
            </div>
        <?php endif; ?>

        
 <a href="<?php echo e(route('supplies.queue')); ?>" class="btn btn-outline-secondary me-2">Back</a>    
    <button class="btn btn-primary checkout-btn">
        <i class="fa-solid fa-circle-check me-2"></i>Checkout
    </button>

    </div>

<?php $__env->startPush('scripts'); ?>

    <script>
         // Checkout SweetAlert Confirmation
        const checkout = document.querySelector('.checkout-btn');

        checkout.addEventListener('click', (e)=>{
            e.preventDefault();

               Swal.fire({
                title: "Are you sure?",
                text: "You are about to submit these charges.",
                icon: "question",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, checkout!"
              }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Submitted!',
                        text: 'Charges have been submitted.',
                        timer: 1500,
                        showConfirmButton: false
                    })

                    document.getElementById('form').submit();
                }
            });
        });
    </script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.supplies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/supplies/show.blade.php ENDPATH**/ ?>