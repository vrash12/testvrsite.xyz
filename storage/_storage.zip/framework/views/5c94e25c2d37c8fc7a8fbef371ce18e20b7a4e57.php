
<?php if($serviceOrders->isEmpty() && $medOrders->isEmpty()): ?>
  <p class="text-muted">No orders found for this patient.</p>
<?php else: ?>

  <?php if($serviceOrders->isNotEmpty()): ?>
    <h6 class="mt-2">Service & Lab Orders</h6>
    <ul class="list-group mb-3">
      <?php $__currentLoopData = $serviceOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $so): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
          <?php echo e($so->service->service_name); ?>

          <span class="badge bg-secondary"><?php echo e(ucfirst($so->service_status)); ?></span>
          <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($so->created_at)->format('M j, Y H:i')); ?></small>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php endif; ?>

  <?php if($medOrders->isNotEmpty()): ?>
    <h6 class="mt-2">Medication Orders</h6>
    <ul class="list-group">
      <?php $__currentLoopData = $medOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
          <?php echo e($mo->service->service_name); ?> &times;<?php echo e($mo->quantity_asked); ?>

          <br>
          <small class="text-muted">
            Ordered on <?php echo e(\Carbon\Carbon::parse($mo->datetime)->format('M j, Y H:i')); ?>

          </small>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php endif; ?>

<?php endif; ?>
<?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/doctor/partials/orders-list.blade.php ENDPATH**/ ?>