


<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

  
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h4 mb-0">Medication Charges</h1>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newChargeModal">
      <i class="fas fa-plus me-1"></i> New Charge
    </button>
  </div>

  
  <div class="card shadow-sm">
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-sm mb-0">
          <thead class="table-light">
            <tr>
              <th>ID</th>
              <th>Date</th>
              <th>Patient</th>
              <th>Rx&nbsp;#</th>
              <th class="text-end">Total</th>
              <th class="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($ch->id); ?></td>
                <td><?php echo e($ch->created_at->format('Y-m-d')); ?></td>
                <td><?php echo e($ch->patient->patient_first_name); ?> <?php echo e($ch->patient->patient_last_name); ?></td>
                <td><?php echo e($ch->rx_number); ?></td>
              <td class="text-end">₱<?php echo e(number_format($ch->items->sum('total'),2)); ?></td>
                <td class="text-center">
                  <button class="btn btn-sm btn-outline-secondary btn-show"
                          data-url="<?php echo e(route('pharmacy.charges.show',$ch)); ?>">
                    View
                  </button>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>

      
      <div class="p-2">
        <?php echo e($charges->links()); ?>

      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="showChargeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold">Medication Charge</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p class="text-muted">Loading…</p>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="newChargeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold">Add New Medication Charge</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <form method="POST" action="<?php echo e(route('pharmacy.charges.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="modal-body">

          
          <div class="mb-3">
            <label class="form-label">Patient</label>
            <select name="patient_id" class="form-select <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
              <option value="">Select patient…</option>
              <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->patient_id); ?>" <?php if(old('patient_id') == $p->patient_id): echo 'selected'; endif; ?>>
                  <?php echo e($p->patient_first_name); ?> <?php echo e($p->patient_last_name); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div class="mb-3">
            <label class="form-label">Prescribing Doctor</label>
            <input type="text" name="prescribing_doctor"
                   value="<?php echo e(old('prescribing_doctor')); ?>"
                   class="form-control <?php $__errorArgs = ['prescribing_doctor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <?php $__errorArgs = ['prescribing_doctor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div class="mb-3">
            <label class="form-label">Rx Number</label>
            <input type="text" name="rx_number"
                   value="<?php echo e(old('rx_number')); ?>"
                   class="form-control <?php $__errorArgs = ['rx_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <?php $__errorArgs = ['rx_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div id="medications-wrapper">
            <div class="row g-2 mb-2 medication-row">
              <div class="col-6">
                <select name="medications[0][service_id]" class="form-select" required>
                  <option value="">Select medication…</option>
                  <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->service_id); ?>"><?php echo e($s->service_name); ?> (₱<?php echo e(number_format($s->price,2)); ?>)</option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-3">
                <input type="number" min="1" name="medications[0][quantity]" class="form-control" placeholder="Qty" required>
              </div>
              <div class="col-3 d-grid">
                <button type="button" class="btn btn-danger btn-remove">Remove</button>
              </div>
            </div>
          </div>
          <button type="button" id="btn-add-med" class="btn btn-outline-primary btn-sm mb-3">
            Add another medication
          </button>

          
          <div class="mb-3">
            <label class="form-label">Notes</label>
            <textarea name="notes" rows="3" class="form-control"><?php echo e(old('notes')); ?></textarea>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Save Charge</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
/* ─── Modal helpers ──────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {

  /* View-charge modal */
  document.querySelectorAll('.btn-show').forEach(btn => {
    btn.addEventListener('click', async () => {
      const url = btn.dataset.url;
      const modalBody = document.querySelector('#showChargeModal .modal-body');
      modalBody.innerHTML = '<p class="text-muted">Loading…</p>';
      new bootstrap.Modal(document.getElementById('showChargeModal')).show();

      try {
        const html = await (await fetch(url, { headers:{'X-Requested-With':'XMLHttpRequest'} })).text();
        modalBody.innerHTML = html;
      } catch (e) {
        modalBody.innerHTML = '<p class="text-danger">Failed to load charge.</p>';
      }
    });
  });

  /* Add-medication repeater */
  const wrapper = document.getElementById('medications-wrapper');
  document.getElementById('btn-add-med').addEventListener('click', () => {
    const idx = wrapper.querySelectorAll('.medication-row').length;
    const tmpl = `
      <div class="row g-2 mb-2 medication-row">
        <div class="col-6">
          <select name="medications[${idx}][service_id]" class="form-select" required>
            <option value="">Select medication…</option>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($s->service_id); ?>"><?php echo e($s->service_name); ?> (₱<?php echo e(number_format($s->price,2)); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="col-3">
          <input type="number" min="1" name="medications[${idx}][quantity]" class="form-control" placeholder="Qty" required>
        </div>
        <div class="col-3 d-grid">
          <button type="button" class="btn btn-danger btn-remove">Remove</button>
        </div>
      </div>`;
    wrapper.insertAdjacentHTML('beforeend', tmpl);
  });

  wrapper.addEventListener('click', e => {
    if (e.target.classList.contains('btn-remove')) {
      e.target.closest('.medication-row').remove();
    }
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.pharmacy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/pharmacy/charges/index.blade.php ENDPATH**/ ?>