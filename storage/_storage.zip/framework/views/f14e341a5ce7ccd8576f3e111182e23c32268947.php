<?php echo csrf_field(); ?>


<div class="mb-3">
  <label class="form-label">Patient</label>
  <input
    list="patients"
    name="search_patient"
    class="form-control <?php $__errorArgs = ['search_patient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
    placeholder="Type name or ID…"
    value="<?php echo e(old('search_patient')); ?>"
    required
  >
  <datalist id="patients">
    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($p->patient_id); ?>">
        <?php echo e($p->patient_first_name); ?> <?php echo e($p->patient_last_name); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </datalist>
  <?php $__errorArgs = ['search_patient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="mb-3">
  <label class="form-label">Ordering Doctor</label>
  <select
    name="doctor_id"
    class="form-select <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
    required
  >
    <option value="">Select doctor…</option>
    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option
        value="<?php echo e($doc->doctor_id); ?>"
        <?php if(old('doctor_id') == $doc->doctor_id): echo 'selected'; endif; ?>
      >
        <?php echo e($doc->doctor_name); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div id="lab-list">
  <div class="lab-item mb-3">
    <h6>Lab Test #1</h6>
    <div class="row g-2">
      <div class="col-md-7">
        <label class="form-label">Test</label>
        <select
          name="charges[0][service_id]"
          class="form-select <?php $__errorArgs = ['charges.0.service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
          required
        >
          <option value="">Select test…</option>
          <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
              value="<?php echo e($s->service_id); ?>"
              data-price="<?php echo e($s->price); ?>"
              <?php if(old('charges.0.service_id') == $s->service_id): echo 'selected'; endif; ?>
            >
              <?php echo e($s->service_name); ?> – ₱<?php echo e(number_format($s->price,2)); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['charges.0.service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="col-md-2">
        <label class="form-label">Unit Price</label>
        <input
          type="text"
          readonly
          class="form-control-plaintext border border-info unit-price"
          value="<?php echo e(old('charges.0.amount') ? number_format(old('charges.0.amount'),2) : ''); ?>"
        >
      </div>
      <div class="col-md-2">
        <label class="form-label">Total</label>
        <input
          type="text"
          readonly
          class="form-control-plaintext border border-warning total-price"
          value="<?php echo e(old('charges.0.amount') ? number_format(old('charges.0.amount'),2) : ''); ?>"
        >
        <input
          type="hidden"
          name="charges[0][amount]"
          class="amount-field"
          value="<?php echo e(old('charges.0.amount') ?: ''); ?>"
        >
      </div>
    </div>
  </div>
</div>

<button
  type="button"
  id="add-test"
  class="btn btn-sm btn-outline-secondary mb-4"
>
  + Add Test
</button>


<div class="mb-3">
  <label class="form-label">Notes (Optional)</label>
  <textarea
    name="notes"
    rows="3"
    class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
  ><?php echo e(old('notes')); ?></textarea>
  <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="mb-4 text-end">
  <strong>Total Amount:</strong>
  ₱<span id="grand-total">
    <?php echo e(old('charges') ? collect(old('charges'))->sum('amount') : '0.00'); ?>

  </span>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
  // start index based on old input count, or 1
  let idx = <?php echo e(old('charges') ? count(old('charges')) : 1); ?>;
  const list = document.getElementById('lab-list');

  // Add new row
  document.getElementById('add-test').addEventListener('click', () => {
    const tpl = list.querySelector('.lab-item').cloneNode(true);
    tpl.querySelector('h6').textContent = `Lab Test #${idx + 1}`;

    tpl.querySelectorAll('[name]').forEach(el => {
      el.name = el.name.replace(/\[\d+\]/, `[${idx}]`);
      if (!el.matches('select')) el.value = '';
    });
    tpl.querySelector('.unit-price').value = '';
    tpl.querySelector('.total-price').value = '';
    tpl.querySelector('.amount-field').value = '';
    list.append(tpl);
    idx++;
  });

  // Recalculate line & grand totals
  function updateLine(item) {
    const sel = item.querySelector('select[name*="[service_id]"]');
    const unit = item.querySelector('.unit-price');
    const total = item.querySelector('.total-price');
    const amount = item.querySelector('.amount-field');

    const price = parseFloat(sel.selectedOptions[0]?.dataset.price || 0);
    unit.value = price.toFixed(2);
    total.value = price.toFixed(2);
    amount.value = price.toFixed(2);

    let gt = 0;
    document.querySelectorAll('.total-price').forEach(el => {
      gt += parseFloat(el.value) || 0;
    });
    document.getElementById('grand-total').textContent = gt.toFixed(2);
  }

  list.addEventListener('change', e => {
    if (e.target.matches('select[name*="[service_id]"]')) {
      updateLine(e.target.closest('.lab-item'));
    }
  });
})();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/laboratory/_form.blade.php ENDPATH**/ ?>