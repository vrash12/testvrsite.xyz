



<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4 border h-100 d-flex flex-column" style="background-color: #fafafa">

    
    <div>
        <h1 class="hdng">Add New Miscellaneous Charge</h1>
        <p>Add new manual charge to patients</p>
    </div>

    <form method="POST" action="<?php echo e(route('supplies.store')); ?>" id="misc-form">
        <?php echo csrf_field(); ?>

        
        <div class="mb-3">
            <label class="form-label">Patient</label>
            <select name="patient_id" class="form-select <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                <option value="">Select patient...</option>
                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->patient_id); ?>" <?php if(old('patient_id') == $p->patient_id): echo 'selected'; endif; ?>>
                        <?php echo e($p->patient_first_name); ?> <?php echo e($p->patient_last_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="border p-3 my-3 flex-grow-1 d-flex flex-column" style="max-height: 350px; overflow-y: auto;">
            <div id="misc-list">
                <div class="misc-item mt-1 border p-3">
                    <h6>Item #1</h6>
                    <div class="row gx-4">
                        <div class="col-md-5">
                            <label class="form-label">Item</label>
                 
<select name="misc_item[0][service_id]"
        class="form-select <?php $__errorArgs = ['misc_item.0.service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        required>
    <option value="">Select Item</option>
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($s->service_id); ?>"
                data-price="<?php echo e($s->price); ?>">
            <?php echo e($s->service_name); ?>

            <small class="text-muted">(<?php echo e($s->department->department_name); ?>)</small>
            – ₱ <?php echo e(number_format($s->price,2)); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

                            <?php $__errorArgs = ['misc_item.0.service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Quantity</label>
                            <input type="number" name="misc_item[0][quantity]" min="1"
                                   class="form-control <?php $__errorArgs = ['misc_item.0.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['misc_item.0.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Unit Price</label>
                            <input type="text" readonly
                                   class="form-control-plaintext border border-info unit-price">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Total</label>
                            <input type="text" readonly
                                   class="form-control-plaintext border border-warning line-total">
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-danger remove-supply">
                                <i class="fa-solid fa-xmark me-2"></i>Remove
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            
            <button type="button" id="add-item" class="btn btn-sm btn-outline-secondary mt-2">+ Add Item</button>
        </div>

        
        <div class="mb-3">
            <label class="form-label">Notes (Optional)</label>
            <textarea name="notes" rows="3"
                      class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      style="resize: none;"><?php echo e(old('notes')); ?></textarea>
            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="text-end mb-3">
            <strong>Total Amount:</strong> ₱<span id="grand-total">0.00</span>
        </div>

        
        <div class="text-end">
            <a href="<?php echo e(route('supplies.dashboard')); ?>" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    let idx = 1;
    const addBtn = document.getElementById('add-item');
    const miscList = document.getElementById('misc-list');

    function updateLineTotals(item) {
        const select    = item.querySelector('select[name^="misc_item"]');
        const qtyInput  = item.querySelector('input[type="number"]');
        const unitPrice = parseFloat(select.selectedOptions[0].dataset.price || 0);
        const qty       = parseInt(qtyInput.value) || 0;
        const unitEl    = item.querySelector('.unit-price');
        const lineEl    = item.querySelector('.line-total');

        unitEl.value = unitPrice.toFixed(2);
        lineEl.value = (unitPrice * qty).toFixed(2);
        updateGrandTotal();
    }

    function updateGrandTotal() {
        let total = 0;
        miscList.querySelectorAll('.line-total').forEach(el => {
            total += parseFloat(el.value) || 0;
        });
        document.getElementById('grand-total').textContent = total.toFixed(2);
    }

    // Recalculate on change
    miscList.addEventListener('change', e => {
        const item = e.target.closest('.misc-item');
        if (item) updateLineTotals(item);
    });

    // Add new item
    addBtn.addEventListener('click', () => {
        const tpl = miscList.querySelector('.misc-item').cloneNode(true);
        idx++;
        tpl.querySelectorAll('input, select').forEach(el => {
            if (el.name) el.name = el.name.replace(/\[\d+\]/, `[${idx-1}]`);
            if (el.tagName === 'SELECT') el.selectedIndex = 0;
            else el.value = '';
            el.classList.remove('is-invalid');
        });
        tpl.querySelectorAll('.invalid-feedback').forEach(f => f.remove());
        tpl.querySelector('h6').textContent = `Item #${idx}`;
        miscList.appendChild(tpl);
    });

    // Remove item
    miscList.addEventListener('click', e => {
        if (e.target.closest('.remove-supply')) {
            const items = miscList.querySelectorAll('.misc-item');
            if (items.length > 1) {
                e.target.closest('.misc-item').remove();
                // re-label
                let i = 1;
                miscList.querySelectorAll('.misc-item').forEach(it => {
                    it.querySelector('h6').textContent = `Item #${i++}`;
                });
                idx = i - 1;
                updateGrandTotal();
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.supplies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/supplies/create.blade.php ENDPATH**/ ?>