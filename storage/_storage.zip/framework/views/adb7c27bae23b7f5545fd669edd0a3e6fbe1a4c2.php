


<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

  
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">Pharmacy Dashboard</h1>
    <a href="<?php echo e(route('pharmacy.charges.create')); ?>" class="btn btn-primary">
      <i class="fas fa-plus"></i> New Medication Charge
    </a>
  </div>

  
  <div class="row gy-3 mb-4">
    <div class="col-md-4">
      <div class="card text-center shadow-sm h-100">
        <div class="card-body">
          <h6 class="text-muted">Total Medication Charges</h6>
          <h2 class="fw-bold"><?php echo e($totalCharges); ?></h2>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card text-center shadow-sm h-100">
        <div class="card-body">
          <h6 class="text-muted">Patients Served</h6>
          <h2 class="fw-bold"><?php echo e($patientsServed); ?></h2>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card text-center shadow-sm h-100">
        <div class="card-body">
          <h6 class="text-muted">Pending Charges</h6>
          <h2 class="fw-bold"><?php echo e($pendingCharges); ?></h2>
        </div>
      </div>
    </div>
  </div>

  
  <form method="GET" class="row g-2 mb-4">
    <div class="col-md-4">
      <input name="q" type="text"
             value="<?php echo e(request('q')); ?>"
             class="form-control"
             placeholder="Search patient or Rx#">
    </div>
    <div class="col-md-3">
      <input name="from" type="date"
             value="<?php echo e(request('from')); ?>"
             class="form-control">
    </div>
    <div class="col-md-3">
      <input name="to" type="date"
             value="<?php echo e(request('to')); ?>"
             class="form-control">
    </div>
    <div class="col-md-2 d-grid">
      <button class="btn btn-outline-secondary">
        <i class="fas fa-filter"></i> Filter
      </button>
    </div>
  </form>

  
  <div class="card shadow-sm mb-4">
    <div class="card-header bg-light d-flex justify-content-between align-items-center">
      <span>Recent Medication Charges • <?php echo e(now()->format('M d, Y')); ?></span>
      <span class="badge bg-primary"><?php echo e($todayCharges->count()); ?></span>
    </div>
    <div class="card-body p-0">
      <table class="table table-hover mb-0 align-middle">
        <thead class="table-light">
          <tr>
            <th>Date</th>
            <th>Rx#</th>
            <th>Patient</th>
            <th>Medications</th>
            <th class="text-end">Total</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $todayCharges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($c->created_at->format('M d, Y')); ?></td>
              <td><?php echo e($c->rx_number); ?></td>
              <td><?php echo e($c->patient->patient_first_name); ?> <?php echo e($c->patient->patient_last_name); ?></td>
              <td><?php echo e($c->items->pluck('service.service_name')->join(', ')); ?></td>
              <td class="text-end">
                ₱<?php echo e(number_format($c->items->sum('total'),2)); ?>

              </td>
              <td class="text-end">
                
                <button type="button"
                        class="btn btn-sm btn-outline-secondary btn-show-charge"
                        data-url="<?php echo e(route('pharmacy.charges.show', $c)); ?>">
                  <i class="fas fa-eye"></i>
                </button>
              </td>
              <td class="text-end">
    <?php if($c->status === 'pending'): ?>
        <form method="POST"
              action="<?php echo e(route('pharmacy.charges.dispense', $c)); ?>"
              onsubmit="return confirm('Mark as dispensed?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <button class="btn btn-success btn-sm">
                <i class="fas fa-check"></i> Dispense
            </button>
        </form>
    <?php else: ?>
        <span class="badge bg-success">Completed</span>
    <?php endif; ?>
</td>

            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6" class="text-center text-muted py-3">
                No charges today.
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <div class="card shadow-sm mb-4">
    <div class="card-header bg-light d-flex justify-content-between align-items-center">
      <span>Earlier</span>
      <span class="badge bg-secondary"><?php echo e($earlierCharges->count()); ?></span>
    </div>
    <div class="card-body p-0">
      <table class="table table-hover mb-0 align-middle">
        <thead class="table-light">
          <tr>
            <th>Date</th>
            <th>Rx#</th>
            <th>Patient</th>
            <th>Medications</th>
            <th class="text-end">Total</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $earlierCharges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($c->created_at->format('M d, Y')); ?></td>
              <td><?php echo e($c->rx_number); ?></td>
              <td><?php echo e($c->patient->patient_first_name); ?> <?php echo e($c->patient->patient_last_name); ?></td>
              <td><?php echo e($c->items->pluck('service.service_name')->join(', ')); ?></td>
              <td class="text-end">
                ₱<?php echo e(number_format($c->items->sum('total'),2)); ?>

              </td>
              <td class="text-end">
                <button type="button"
                        class="btn btn-sm btn-outline-secondary btn-show-charge"
                        data-url="<?php echo e(route('pharmacy.charges.show', $c)); ?>">
                  <i class="fas fa-eye"></i>
                </button>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6" class="text-center text-muted py-3">
                No earlier charges.
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>


<div class="modal fade" id="chargeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Medication Charge Details</h5>

      </div>
      <div class="modal-body">
        <p class="text-center text-muted">Loading...</p>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const modalEl = document.getElementById('chargeModal');
  const modal    = new bootstrap.Modal(modalEl);
  const body     = modalEl.querySelector('.modal-body');

  document.querySelectorAll('.btn-show-charge').forEach(btn => {
    btn.addEventListener('click', async () => {
      const url = btn.dataset.url;
      body.innerHTML = '<p class="text-center text-muted">Loading...</p>';
      modal.show();

      try {
        // fetch the partial view via AJAX
        const res  = await fetch(url, {
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const html = await res.text();
        body.innerHTML = html;
      } catch (err) {
        body.innerHTML = '<p class="text-danger text-center">Failed to load details.</p>';
        console.error(err);
      }
    });
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.pharmacy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/pharmacy/dashboard.blade.php ENDPATH**/ ?>