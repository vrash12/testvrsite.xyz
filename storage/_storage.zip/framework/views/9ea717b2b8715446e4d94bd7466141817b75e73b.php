


<?php $__env->startSection('content'); ?>
<div class="container-fluid">

  <h2 class="fw-bold mb-2">Order Entry</h2>
  <p class="text-muted mb-4">Create Prescriptions and Order services for patients</p>

  
  <div class="card mb-4">
    <div class="card-body d-flex align-items-start">
      <div class="rounded-circle bg-light flex-shrink-0 me-3" style="width:48px;height:48px;"></div>
      <div class="flex-grow-1">
        <div class="d-flex align-items-center mb-1">
          <strong class="me-2"><?php echo e($patient->patient_first_name); ?> <?php echo e($patient->patient_last_name); ?></strong>
          <span class="text-muted small">| P-<?php echo e($patient->patient_id); ?></span>
        </div>
        <div class="small text-muted">
          <?php echo e(ucfirst($patient->civil_status)); ?>, <?php echo e($patient->patient_birthday?->age); ?> yrs •
          DOB: <?php echo e($patient->patient_birthday?->format('m/d/Y')); ?><br>
          MRN: <span class="fw-semibold"><?php echo e($patient->mrn ?? 'N/A'); ?></span><br>
          Allergies:
          <?php $__empty_1 = true; $__currentLoopData = $patient->medicalDetail?->allergies ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allergy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <span class="badge bg-danger-subtle text-danger border border-danger me-1"><?php echo e($allergy); ?></span>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <span class="text-muted">None</span>
          <?php endif; ?>
        </div>
      </div>
      <a href="<?php echo e(route('doctor.dashboard')); ?>" class="btn btn-outline-secondary btn-sm ms-3">
        <i class="fa-solid fa-xmark me-1"></i> Change Patient
      </a>
    </div>
  </div>

  
  <style>
    .nav-tabs .nav-link       { color:#00529A; font-weight:600; }
    .nav-tabs .nav-link:hover { color:#003f7a; }
    .nav-tabs .nav-link.active{
      background-color:#00529A; color:#fff; border-color:#00529A;
    }
  </style>

  
  <ul class="nav nav-tabs nav-fill mb-3" id="orderTabs" role="tablist">
    <li class="nav-item">
      <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#medications" type="button">
        💊 Medications
      </button>
    </li>
    <li class="nav-item">
      <button class="nav-link" data-bs-toggle="tab" data-bs-target="#laboratory" type="button">
        🧪 Lab & Imaging
      </button>
    </li>
    <li class="nav-item">
      <button class="nav-link" data-bs-toggle="tab" data-bs-target="#services" type="button">
        🛠️ Other Services
      </button>
    </li>
  </ul>

  <div class="tab-content">


<div class="tab-pane fade show active" id="medications">
  <form method="POST" action="<?php echo e(route('doctor.orders.store', $patient)); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="type" value="medication">

    <div id="med-wrapper">
   
<div class="med-row border rounded p-3 mb-3">
  
  <div class="row g-3 mb-2">
    <div class="col-md-6">
      <label class="form-label">Medication</label>
      <select class="form-select" name="medications[0][medication_id]" required>
        <option value="" disabled selected>Select medication</option>
        <?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($med->service_id); ?>"><?php echo e($med->service_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="col-md-2">
      <label class="form-label">Qty</label>
      <input type="number" min="1" class="form-control"
             name="medications[0][quantity]" value="1" required>
    </div>

    <div class="col-md-2">
      <label class="form-label">Duration</label>
      <input type="number" min="1" class="form-control"
             name="medications[0][duration]" value="1" required>
    </div>

    <div class="col-md-2">
      <label class="form-label">Unit</label>
      <select class="form-select" name="medications[0][duration_unit]" required>
        <option value="days">Days</option>
        <option value="weeks">Weeks</option>
      </select>
    </div>
  </div>

  
  <div class="row g-3">
    <div class="col-md-10">
      <label class="form-label">Special Instructions</label>
      <textarea class="form-control"
                name="medications[0][instructions]"
                rows="2"></textarea>
    </div>
    <div class="col-md-2 d-grid">
      <button type="button" class="btn btn-danger btn-remove-med mt-4">✕ Remove</button>
    </div>
  </div>
</div>

    </div>

    <button type="button" id="btn-add-med" class="btn btn-outline-primary btn-sm mb-4">
      + Add Medication
    </button>

    <div class="d-flex justify-content-end">
      <a href="<?php echo e(route('doctor.dashboard')); ?>" class="btn btn-light me-2">Cancel</a>
      <button type="submit" class="btn btn-primary">Submit Medication Order</button>
    </div>
  </form>
</div>

  
<div class="tab-pane fade" id="laboratory">
  <form method="POST" action="<?php echo e(route('doctor.orders.store', $patient)); ?>" class="row gy-3">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="type" value="lab">

    
    <div class="col-12">
      <label class="form-label">Select Laboratory Tests & Imaging Studies</label>
      <div class="row g-2">
        <?php $__currentLoopData = $labTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6">
            <div class="form-check">
              <input class="form-check-input"
                     type="checkbox"
                     name="labs[]"
                     value="<?php echo e($lab->service_id); ?>"
                     id="lab<?php echo e($lab->service_id); ?>">
              <label class="form-check-label" for="lab<?php echo e($lab->service_id); ?>">
                <?php echo e($lab->service_name); ?>

              </label>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $imagingStudies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6">
            <div class="form-check">
              <input class="form-check-input"
                     type="checkbox"
                     name="studies[]"
                     value="<?php echo e($img->service_id); ?>"
                     id="img<?php echo e($img->service_id); ?>">
              <label class="form-check-label" for="img<?php echo e($img->service_id); ?>">
                <?php echo e($img->service_name); ?>

              </label>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>

    
    <div class="col-12">
      <label class="form-label">Diagnosis / Clinical Indication</label>
      <textarea class="form-control" name="diagnosis" rows="2"></textarea>
    </div>

    
    <div class="col-md-4">
      <label class="form-label">Date</label>
      <input type="date"
             class="form-control"
             name="collection_date"
             value="<?php echo e(now()->toDateString()); ?>">
    </div>

    
    <div class="col-md-8">
      <label class="form-label d-block">Priority</label>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="priority" value="routine" checked>
        <label class="form-check-label">Routine</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="priority" value="urgent">
        <label class="form-check-label">Urgent</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="priority" value="stat">
        <label class="form-check-label">STAT</label>
      </div>
    </div>

    
    <div class="col-12 d-flex justify-content-end">
      <a href="<?php echo e(route('doctor.dashboard')); ?>" class="btn btn-light me-2">Cancel</a>
      <button type="submit" class="btn btn-primary">Submit Lab & Imaging Order</button>
    </div>
  </form>
</div>



<div class="tab-pane fade" id="services">
  <form method="POST" action="<?php echo e(route('doctor.orders.store', $patient)); ?>" class="row gy-3">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="type" value="service">

    
    <div class="col-12">
      <label class="form-label">Select Services</label>
      <div class="row g-2">
        <?php $__currentLoopData = $otherServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6">
            <div class="form-check">
              <input class="form-check-input"
                     type="checkbox"
                     name="services[]"
                     value="<?php echo e($svc->service_id); ?>"
                     id="service<?php echo e($svc->service_id); ?>">
              <label class="form-check-label" for="service<?php echo e($svc->service_id); ?>">
                <?php echo e($svc->service_name); ?>

              </label>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>

    
    <div class="col-12">
      <label class="form-label">Diagnosis / Clinical Indication</label>
      <textarea class="form-control" name="diagnosis" rows="2"></textarea>
    </div>

    
    <div class="col-md-6">
      <label class="form-label">Scheduled Date</label>
      <input type="date"
             class="form-control"
             name="scheduled_date"
             value="<?php echo e(now()->toDateString()); ?>">
    </div>

    
    <div class="col-md-6">
      <label class="form-label d-block">Priority</label>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="priority" value="routine" checked>
        <label class="form-check-label">Routine</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="priority" value="urgent">
        <label class="form-check-label">Urgent</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="priority" value="stat">
        <label class="form-check-label">STAT</label>
      </div>
    </div>

    
    <div class="col-12 d-flex justify-content-end">
      <a href="<?php echo e(route('doctor.dashboard')); ?>" class="btn btn-light me-2">Cancel</a>
      <button type="submit" class="btn btn-primary">Submit Service Order</button>
    </div>
  </form>
</div>


  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const wrapper = document.getElementById('med-wrapper');
  const addBtn  = document.getElementById('btn-add-med');

  // Clone & index a new med-row
  addBtn.addEventListener('click', () => {
    const idx  = wrapper.querySelectorAll('.med-row').length;
    let html    = wrapper.querySelector('.med-row').outerHTML;
    html        = html.replaceAll('[0]', `[${idx}]`);
    wrapper.insertAdjacentHTML('beforeend', html);
    bindRemove();
  });

  // Bind Remove buttons
  function bindRemove() {
    wrapper.querySelectorAll('.btn-remove-med').forEach(btn => {
      btn.onclick = () => {
        const rows = wrapper.querySelectorAll('.med-row');
        if (rows.length > 1) {
          btn.closest('.med-row').remove();
        }
      };
    });
  }

  bindRemove(); // initial row
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/doctor/order-entry.blade.php ENDPATH**/ ?>