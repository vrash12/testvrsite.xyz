

<?php $__env->startSection('content'); ?>
<div class="mx-auto" style="max-width:950px">

    
    <div class="card shadow-sm">
        <div class="card-body px-5 py-4">

            <h4 class="mb-4 fw-bold text-primary">My Profile</h4>
   <div class="d-flex mb-4">
                <div>
                    <?php if($patient->profile_photo): ?>
                        <img src="<?php echo e(asset('storage/patient/images/'.$patient->profile_photo)); ?>"
                             class="rounded-circle" width="100" height="100">
                    <?php else: ?>
                        <div class="rounded-circle bg-secondary" style="width:100px;height:100px;"></div>
                    <?php endif; ?>
                </div>
                <div class="ms-4 align-self-center">
                    <label class="form-label">Change Photo</label><br>
                    <input type="file" name="profile_photo" form="profile-form" class="form-control-file">
                </div>
            </div>
      <form id="profile-form" method="POST" action="<?php echo e(route('patient.account.update')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>

  <div class="row g-3 mb-3">
    <div class="col-md-4">
      <label class="form-label">Last Name</label>
      <input type="text" name="patient_last_name"
             value="<?php echo e(old('patient_last_name', $patient->patient_last_name)); ?>"
             class="form-control" required>
    </div>

    <div class="col-md-4">
      <label class="form-label">First Name</label>
      <input type="text" name="patient_first_name"
             value="<?php echo e(old('patient_first_name', $patient->patient_first_name)); ?>"
             class="form-control" required>
    </div>

    <div class="col-md-4">
      <label class="form-label">Middle Initial</label>
      <input type="text" name="middle_initial"
             value="<?php echo e(old('middle_initial', $patient->middle_initial)); ?>"
             maxlength="1" class="form-control">
    </div>

    <div class="col-md-2">
      <label class="form-label">Sex</label>
      <select name="sex" class="form-select">
        <option value="">—</option>
        <option value="male"   <?php if(old('sex', strtolower($patient->sex ?? ''))=='male'): echo 'selected'; endif; ?>>Male</option>
        <option value="female" <?php if(old('sex', strtolower($patient->sex ?? ''))=='female'): echo 'selected'; endif; ?>>Female</option>
        <option value="other"  <?php if(old('sex', strtolower($patient->sex ?? ''))=='other'): echo 'selected'; endif; ?>>Other</option>
      </select>
    </div>

    <div class="col-md-3">
      <label class="form-label">Birthday</label>
      <input type="date" name="patient_birthday"
             value="<?php echo e(old('patient_birthday', optional($patient->patient_birthday)->format('Y-m-d'))); ?>"
             class="form-control">
    </div>

    <div class="col-md-3">
      <label class="form-label">Civil Status</label>
      <select name="civil_status" class="form-select">
        <option value="">—</option>
        <?php $__currentLoopData = ['single','married','widowed','divorced']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($status); ?>"
            <?php if(old('civil_status', $patient->civil_status)==$status): echo 'selected'; endif; ?>>
            <?php echo e(ucfirst($status)); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="col-md-4">
      <label class="form-label">Email</label>
      <input type="email" name="email"
             value="<?php echo e(old('email', $patient->email)); ?>"
             class="form-control" required>
    </div>

    <div class="col-md-4">
      <label class="form-label">Contact #</label>
      <input type="text" name="phone_number"
             value="<?php echo e(old('phone_number', $patient->phone_number)); ?>"
             class="form-control">
    </div>
  </div>

  <button type="submit" class="btn btn-primary px-4">Save Changes</button>
</form>


        </div>
    </div>

    
    <div class="card shadow-sm mt-5">
        <div class="card-body px-5 py-4">

            <h4 class="mb-4 fw-bold text-primary">Change Password</h4>

            <form method="POST" action="<?php echo e(route('patient.account.password')); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>

                <div class="row g-3 mb-3">
                    
                    <div class="col-md-4">
                        <label class="form-label">Current Password</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>

                    
                    <div class="col-md-4">
                        <label class="form-label">New Password</label>
                        <input type="password" name="password" class="form-control" required minlength="8">
                    </div>

                    
                    <div class="col-md-4">
                        <label class="form-label">Confirm Password</label>
                        <input type="password" name="password_confirmation" class="form-control" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary px-4">Save New Password</button>
            </form>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.patients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/patient/account.blade.php ENDPATH**/ ?>