


<?php $__env->startSection('content'); ?>
<div class="container-fluid h-100 border p-4 flex-column" style="background-color: #fafafa;">

    
    <div class="mb-4">
        <h5 class="hdng">Operating Room Services Management</h5>
        <p>Welcome to the OR dashboard! Manage Procedures and Service Completion</p>
    </div>

    
    <div class="row g-3 mb-4">
        <div class="col-lg-4 col-md-6">
            <div class="card border">
                <div class="card-body d-flex align-items-center">
                    <i class="fa-solid fa-procedures fa-2x text-secondary me-4"></i>
                    <div>
                        <div class="text-muted small">Procedures Completed</div>
                        <h5 class="mb-0"><?php echo e($completedCount); ?></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card border">
                <div class="card-body d-flex align-items-center">
                    <i class="fa-solid fa-users fa-2x text-secondary me-4"></i>
                    <div>
                        <div class="text-muted small">Patients Served</div>
                        <h5 class="mb-0"><?php echo e($patientsServed->count()); ?></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card border">
                <div class="card-body d-flex align-items-center">
                    <i class="fa-solid fa-hourglass-start fa-2x text-secondary me-4"></i>
                    <div>
                        <div class="text-muted small">Pending Procedures</div>
                        <h5 class="mb-0"><?php echo e($pendingCount); ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header bg-light">
            <h6 class="mb-0">
                <i class="fa-solid fa-calendar-day me-2 text-secondary"></i>
                Today's Procedures
            </h6>
        </div>
        <div class="table-responsive p-2">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Patient</th>
                        <th>Procedure</th>
                        <th>Assigned By</th>
                        <th>OR No.</th>
                        <th class="text-end">Amount</th>
                        <th class="text-center">Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $todayProcedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $proc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i + 1); ?></td>
                            <td>
                                <div class="fw-semibold">
                                    <?php echo e($proc->patient->patient_first_name); ?>

                                    <?php echo e($proc->patient->patient_last_name); ?>

                                </div>
                                <small class="text-muted">P-<?php echo e($proc->patient->patient_id); ?></small>
                            </td>
                            <td><?php echo e($proc->service->service_name); ?></td>
                            <td>
                                <span class="badge bg-info text-white"><?php echo e($proc->doctor->doctor_name); ?></span>
                            </td>
                            <td><?php echo e($proc->room ?? '–'); ?></td>
                            <td class="text-end">₱<?php echo e(number_format($proc->amount, 2)); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('operating.details', $proc)); ?>" class="btn btn-sm btn-outline-secondary">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="text-center">
                            <td colspan="7" class="text-warning">No procedures today</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header bg-light">
            <h6 class="mb-0">
                <i class="fa-solid fa-clock-rotate-left me-2 text-secondary"></i>
                Earlier Procedures
            </h6>
        </div>
        <div class="table-responsive p-2">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Patient</th>
                        <th>Procedure</th>
                        <th>Assigned By</th>
                        <th>OR No.</th>
                        <th class="text-end">Amount</th>
                        <th class="text-center">Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $earlierProcedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $proc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i + 1); ?></td>
                            <td>
                                <div class="fw-semibold">
                                    <?php echo e($proc->patient->patient_first_name); ?>

                                    <?php echo e($proc->patient->patient_last_name); ?>

                                </div>
                                <small class="text-muted">P-<?php echo e($proc->patient->patient_id); ?></small>
                            </td>
                            <td><?php echo e($proc->service->service_name); ?></td>
                            <td>
                                <span class="badge bg-info text-white"><?php echo e($proc->doctor->doctor_name); ?></span>
                            </td>
                            <td><?php echo e($proc->room ?? '–'); ?></td>
                            <td class="text-end">₱<?php echo e(number_format($proc->amount, 2)); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('operating.details', $proc)); ?>" class="btn btn-sm btn-outline-secondary">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="text-center">
                            <td colspan="7" class="text-warning">No earlier procedures</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.operatingroom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/operatingroom/dashboard.blade.php ENDPATH**/ ?>