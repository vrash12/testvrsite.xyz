
<div>
  
  <div class="d-flex justify-content-between mb-3">
    <h5 class="mb-0">Medication Charge — Rx #<?php echo e($charge->rx_number); ?></h5>
 <span class="fs-5 fw-bold">
   Total ₱<?php echo e(number_format($charge->items->sum('total'), 2)); ?>

 </span>
  </div>

  
  <table class="table table-sm align-middle">
    <thead class="table-light">
      <tr>
        <th>Medication</th>
        <th class="text-center">Qty</th>
        <th class="text-end">Unit Price</th>
        <th class="text-end">Line Total</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $charge->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(optional($item->service)->service_name ?: '—'); ?></td>
          <td class="text-center"><?php echo e($item->quantity); ?></td>
          <td class="text-end">₱<?php echo e(number_format($item->unit_price, 2)); ?></td>
          <td class="text-end">₱<?php echo e(number_format($item->total,      2)); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  
  <div class="text-end mt-3">
    <button class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">
      Close
    </button>
    <a href="<?php echo e(route('pharmacy.charges.index')); ?>" class="btn btn-sm btn-primary">
      Back to list
    </a>
  </div>
</div>
<?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/pharmacy/charges/show.blade.php ENDPATH**/ ?>