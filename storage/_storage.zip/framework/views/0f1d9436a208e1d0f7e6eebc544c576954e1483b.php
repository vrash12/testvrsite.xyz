


<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
  <h1>Rooms & Beds</h1>
  <div class="d-flex gap-2">
    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addRoomModal">
      <i class="fas fa-door-open me-1"></i> Add Room
    </button>
    <button class="btn btn-sm btn-secondary" data-bs-toggle="modal" data-bs-target="#addBedModal">
      <i class="fas fa-bed me-1"></i> Add Bed
    </button>
  </div>
</div>

<table class="table table-hover">
  <thead class="table-light">
    <tr>
      <th>Room #</th>
      <th>Department</th>
      <th>Total Beds</th>
      <th>Available Beds</th>
      <th>Beds (status)</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $total     = $room->beds->count();
        $available = $room->beds->where('status','available')->count();
      ?>
      <tr>
        <td><?php echo e($room->room_number); ?></td>
        <td><?php echo e($room->department->department_name); ?></td>
        <td><?php echo e($total); ?></td>
        <td><?php echo e($available); ?></td>
        <td>
          <ul class="mb-0 ps-3">
            <?php $__currentLoopData = $room->beds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="small d-flex align-items-center">
                <?php echo e($bed->bed_number); ?>

                <span class="badge bg-<?php echo e($bed->status==='available'?'success':'secondary'); ?> ms-1 me-2">
                  <?php echo e(ucfirst($bed->status)); ?>

                </span>
                <a href="<?php echo e(route('admin.resources.edit',['type'=>'bed','id'=>$bed->bed_id])); ?>">✎</a>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </td>
        <td class="d-flex gap-2">
          <a href="<?php echo e(route('admin.resources.edit',['type'=>'room','id'=>$room->room_id])); ?>">Edit</a>
          <form action="<?php echo e(route('admin.resources.destroy',['type'=>'room','id'=>$room->room_id])); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this room and its beds?')">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


<div class="modal fade" id="addRoomModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form class="modal-content" action="<?php echo e(route('admin.resources.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="type" value="room">
      <div class="modal-header"><h5 class="modal-title">New Room</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Department</label>
          <select name="department_id" class="form-select" required>
            <option value="">Select…</option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($d->department_id); ?>"><?php echo e($d->department_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Room Number</label>
          <input name="room_number" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Capacity</label>
          <input name="capacity" type="number" min="1" value="1" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Status</label>
          <select name="status" class="form-select" required>
            <option value="available">Available</option>
            <option value="unavailable">Unavailable</option>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Daily Rate (₱)</label>
          <input name="rate" type="number" step="0.01" min="0" value="0" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Create Room</button>
      </div>
    </form>
  </div>
</div>


<div class="modal fade" id="addBedModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form class="modal-content" action="<?php echo e(route('admin.resources.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="type" value="bed">
      <div class="modal-header"><h5 class="modal-title">New Bed</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Room</label>
          <select name="room_id" class="form-select" required>
            <option value="">Select…</option>
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($r->room_id); ?>"><?php echo e($r->room_number); ?> (<?php echo e($r->department->department_name); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Bed Number</label>
          <input name="bed_number" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Daily Rate (₱)</label>
          <input name="rate" type="number" step="0.01" min="0" value="0" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Status</label>
          <select name="status" class="form-select" required>
            <option value="available">Available</option>
            <option value="occupied">Occupied</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Create Bed</button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/admin/resources/index.blade.php ENDPATH**/ ?>