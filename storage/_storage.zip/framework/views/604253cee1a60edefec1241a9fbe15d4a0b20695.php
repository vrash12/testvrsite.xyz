


<?php $__env->startSection('content'); ?>
<div class="container-fluid h-100 border p-5 d-flex flex-column" style="background-color: #fafafa;">
    
    <div class="row align-items-center justify-content-between mb-3">
        <div class="col">
            <h1 class="hdng mb-1">Patient Admission Management</h1>
            <p class="text-muted mb-2">Manage admitted patients and assign doctors</p>
        </div>
        <div class="col-auto">
            <a href="<?php echo e(route('admission.patients.create')); ?>" class="btn btn-outline-primary">
                <i class="fa-solid fa-user-plus me-2"></i>Admit new Patient
            </a>
        </div>
    </div>

    
    <form method="GET" action="<?php echo e(route('admission.patients.index')); ?>">
        <div class="row mb-3">
            <div class="col-md-11">
                <input
                    type="text"
                    name="q"
                    class="form-control"
                    placeholder="MRN or Patient Name"
                    value="<?php echo e(request('q')); ?>"
                >
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-outline-primary w-100">
                    <i class="fa-solid fa-magnifying-glass me-2"></i>Search
                </button>
            </div>
        </div>
    </form>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <table class="table table-bordered table-hover mb-3">
        <thead>
            <tr>
                <th>MRN</th>
                <th>Name</th>
                <th>Room</th>
                <th>Admission Date</th>
                <th>Assigned Doctor</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($patient->patient_id); ?></td>
                    <td><?php echo e($patient->patient_first_name); ?> <?php echo e($patient->patient_last_name); ?></td>
                    <td><?php echo e($patient->admissionDetail?->room_number ?? '—'); ?></td>
                    <td><?php echo e($patient->admissionDetail?->admission_date?->format('Y-m-d') ?? '—'); ?></td>
                    <td><?php echo e($patient->admissionDetail?->doctor?->doctor_name ?? '—'); ?></td>
                    <td>
                        <?php
                            $badge = match(strtolower($patient->status)) {
                                'active'    => 'bg-success',
                                'completed' => 'bg-primary',
                                'pending'   => 'bg-warning',
                                default     => 'bg-secondary'
                            };
                        ?>
                        <span class="badge text-white <?php echo e($badge); ?>">
                            <?php echo e(ucfirst($patient->status)); ?>

                        </span>
                    </td>
                    <td>
                        
                        <a href="<?php echo e(route('admission.patients.show', $patient->patient_id)); ?>" class="btn btn-sm btn-primary">
                            <i class="fa-solid fa-eye me-2"></i>View
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted">No patients found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    
    <div class="d-flex justify-content-end">
        <?php echo e($patients->withQueryString()->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/patients/index.blade.php ENDPATH**/ ?>