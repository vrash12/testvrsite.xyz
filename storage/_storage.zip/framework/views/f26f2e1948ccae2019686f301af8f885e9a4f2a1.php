


<?php $__env->startSection('content'); ?>
  <div class="page-header mb-4">
    <h1 class="h3">New Patient Admission</h1>
  </div>

  <form method="POST" action="<?php echo e(route('admission.patients.store')); ?>" novalidate>
    <?php echo $__env->make('patients._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="mt-4 text-end">
      <a href="<?php echo e(route('admission.patients.index')); ?>" class="btn btn-secondary">Cancel</a>
      <button type="submit" class="btn btn-success">Save</button>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/patients/create.blade.php ENDPATH**/ ?>