


<?php $__env->startSection('content'); ?>

  <div class="container-fluid bg-secondary px-20" style="margin-top:80px; padding: 30px 45px;">
    <h1 class="fs-1">Billing</h1>
    <h3 class="fs-2">Module</h3>
    <p>Access your Billing Information using the billing portal</p>
  </div>

<div class="container mt-5">

  <div class="row justify-content-center sm:m-5">
    
    
    <div class="col-lg-4 col-md-6 col-sm-6 border rounded p-4">

      <h2 class="mb-4 text-center">Login to PatientCare</h2>

      
      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($err); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('login.attempt')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
          <label>Email address</label>
          <input
            type="email"
            name="email"
            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old('email')); ?>"
            required
            autofocus
          >
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
          <label>Password</label>
          <input
            type="password"
            name="password"
            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            required
          >
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3 form-check">
          <input
            type="checkbox"
            name="remember"
            class="form-check-input"
            id="remember"
          >
          <label class="form-check-label" for="remember">Remember Me</label>
        </div>

        <button type="submit" class="btn btn-primary w-100">Login</button>
      </form>
    </div>

    
    <div class="col-lg-4 col-md-6 col-sm-6 bg-white border px-2 py-5">
      <h3 class="text-center">Instructions for Using PatientCare Portal</h3>
      <ol class="list-group list-group-numbered mt-3">
        <li class="list-group-item">Go to admission department and get admitted.</li>
        <li class="list-group-item">Register email at admission.</li>
        <li class="list-group-item">Check your email.</li>
        <li class="list-group-item">Login to the portal.</li>
        <li class="list-group-item">View your bill.</li>
        <li class="list-group-item">Stay updated.</li>
        <li class="list-group-item">Bootstrap is killing me.</li>
      </ol>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/auth/login.blade.php ENDPATH**/ ?>