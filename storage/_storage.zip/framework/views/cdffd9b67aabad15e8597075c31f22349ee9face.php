


<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
  <h1 class="h4 mb-3">Add New Operating-Room Charge</h1>

  <form method="POST" action="<?php echo e(route('operating.store')); ?>" id="or-form">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
  <label class="form-label">Ordering Doctor</label>
  <select name="doctor_id"
          class="form-select <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
    <option value="">Select doctor…</option>
    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($doc->doctor_id); ?>"
        <?php if(old('doctor_id') == $doc->doctor_id): echo 'selected'; endif; ?>>
        Dr. <?php echo e($doc->doctor_name); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
    
    <div class="mb-3">
      <label class="form-label">Patient</label>
      <select name="patient_id" class="form-select <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
        <option value="">Select patient…</option>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($p->patient_id); ?>" <?php if(old('patient_id') == $p->patient_id): echo 'selected'; endif; ?>>
            <?php echo e($p->patient_first_name); ?> <?php echo e($p->patient_last_name); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div id="procedure-list">
      <div class="procedure-item mb-3">
        <h6>Procedure #1</h6>
        <div class="row g-2">
          <div class="col-md-6">
            <label class="form-label">Procedure</label>
            <select name="misc_item[0][service_id]"
                    class="form-select <?php $__errorArgs = ['misc_item.0.service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
              <option value="">Select procedure…</option>
              <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s->service_id); ?>" data-price="<?php echo e($s->price); ?>">
                  <?php echo e($s->service_name); ?> – ₱<?php echo e(number_format($s->price,2)); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['misc_item.0.service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-2">
            <label class="form-label">OR No.</label>
            <input type="number" name="misc_item[0][orNumber]" min="1"
                   class="form-control <?php $__errorArgs = ['misc_item.0.orNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['misc_item.0.orNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-2">
            <label class="form-label">Unit Price</label>
            <input type="text" readonly class="form-control-plaintext border border-info unit-price">
          </div>
          <div class="col-md-2">
            <label class="form-label">Total</label>
            <input type="text" readonly class="form-control-plaintext border border-warning total-price">
          </div>
        </div>
      </div>
    </div>

    <button type="button" id="add-procedure" class="btn btn-sm btn-outline-secondary mb-4">
      + Add Procedure
    </button>

    
    <div class="mb-3">
      <label class="form-label">Notes (Optional)</label>
      <textarea name="notes" rows="3"
                class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('notes')); ?></textarea>
      <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-4 text-end">
      <strong>Total Amount:</strong> ₱<span id="grand-total">0.00</span>
    </div>

    <div class="text-end">
      <a href="<?php echo e(route('operating.dashboard')); ?>" class="btn btn-secondary">Cancel</a>
      <button type="submit" class="btn btn-primary">Create Charge</button>
    </div>
  </form>
</div>


<div class="modal fade" id="addChargeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <form id="add-charge-form" method="POST" action="<?php echo e(route('operating.store')); ?>" class="modal-content">
      <?php echo csrf_field(); ?>
      <div class="modal-header">
        <h5 class="modal-title">Add OR Charge</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <input type="hidden" name="patient_id" id="modal-patient-id">
        <div class="row g-3">
          
          <div class="col-md-6">
            <label class="form-label fw-semibold">Patient</label>
            <input id="modal-patient-name" class="form-control-plaintext" readonly>
          </div>

          
          <div class="col-md-6">
            <label for="doctor_id" class="form-label fw-semibold">Doctor</label>
            <select name="doctor_id" id="doctor_id" class="form-select" required>
              <option value="">Choose…</option>
              <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($doc->doctor_id); ?>"
                  <?php if(optional(Auth::user()->doctor)->doctor_id === $doc->doctor_id): echo 'selected'; endif; ?>>
                  <?php echo e($doc->doctor_name); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          
          <div class="col-md-8">
            <label class="form-label fw-semibold">Procedure / Service</label>
            <select name="misc_item[0][service_id]" class="form-select" required>
              <option value="">Choose…</option>
              <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($svc->service_id); ?>">
                  <?php echo e($svc->service_name); ?> — ₱<?php echo e(number_format($svc->price,2)); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          
          <div class="col-md-4">
            <label class="form-label fw-semibold">OR No.</label>
            <input type="number" name="misc_item[0][orNumber]" class="form-control" min="1">
          </div>

          
          <div class="col-12">
            <label class="form-label fw-semibold">Notes</label>
            <textarea name="notes" rows="2" class="form-control"></textarea>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Charge</button>
      </div>
    </form>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
(function () {

  // idx will be used both for naming indexes and for OR numbers
  let idx = 1;
   const list = document.getElementById('procedure-list');

  //─── initialize first OR No. ─────────────────────────────────────
  const firstOrInput = document.querySelector('input[name="misc_item[0][orNumber]"]');
  if (firstOrInput) {
    firstOrInput.value = 1;
  }

   // Add new procedure block
   document.getElementById('add-procedure').addEventListener('click', () => {
     const tpl = list.querySelector('.procedure-item').cloneNode(true);
     tpl.querySelector('h6').textContent = `Procedure #${idx + 1}`;

     // Re-index name attributes
     tpl.querySelectorAll('[name]').forEach(el => {
       el.name = el.name.replace(/\[\d+\]/, `[${idx}]`);
       if (!el.matches('select')) el.value = '';
     });

    //─── auto-set OR No. to idx+1 ─────────────────────────────────────
    const orInput = tpl.querySelector('input[name*="[orNumber]"]');
    if (orInput) {
      orInput.value = idx + 1;
    }

     // Clear price fields
     tpl.querySelector('.unit-price').value = '';
     tpl.querySelector('.total-price').value = '';

     list.append(tpl);
     idx++;
   });

   // Recalculate line + grand total
   function updateLine(item) {
     const sel   = item.querySelector('select[name*="[service_id]"]');
     const unit  = item.querySelector('.unit-price');
     const total = item.querySelector('.total-price');

     const price = parseFloat(sel.selectedOptions[0]?.dataset.price || 0);
     unit.value  = price.toFixed(2);
     total.value = price.toFixed(2);

     // grand total
     let gt = 0;
     document.querySelectorAll('.total-price').forEach(el => {
       gt += parseFloat(el.value) || 0;
     });
     document.getElementById('grand-total').textContent = gt.toFixed(2);
   }

   // Delegate change events
   list.addEventListener('change', e => {
     if (e.target.matches('select[name*="[service_id]"]')) {
       updateLine(e.target.closest('.procedure-item'));
     }
   });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.operatingroom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/operatingroom/create.blade.php ENDPATH**/ ?>