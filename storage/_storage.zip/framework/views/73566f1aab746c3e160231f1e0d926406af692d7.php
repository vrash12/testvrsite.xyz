
<?php
  // ensure $patient is always defined
  $patient   = $patient ?? null;
  $admission = optional($patient)->admissionDetail;
  $medical   = optional($patient)->medicalDetail;
  $billing   = optional($patient)->billingInformation;
?>

<?php echo csrf_field(); ?>
<?php if(isset($patient)): ?>
  <?php echo method_field('PUT'); ?>
<?php endif; ?>

<style>
  /* mark completed tabs with a green check */
  .nav-tabs .nav-link.completed {
    color: #28a745;
  }
  .nav-tabs .nav-link.completed::after {
    content: ' ✓';
    color: #28a745;
    font-weight: bold;
  }
</style>

<ul class="nav nav-tabs mb-3" id="patientTabs" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active" id="personal-tab" data-bs-toggle="tab" data-bs-target="#personal"
            type="button" role="tab">Personal Information</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="medical-tab" data-bs-toggle="tab" data-bs-target="#medical"
            type="button" role="tab">Medical Details</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="admission-tab" data-bs-toggle="tab" data-bs-target="#admission"
            type="button" role="tab">Admission Details</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="billing-tab" data-bs-toggle="tab" data-bs-target="#billing"
            type="button" role="tab">Billing Details</button>
  </li>
</ul>

<div class="tab-content" id="patientTabsContent">
  
  <div class="tab-pane fade show active" id="personal" role="tabpanel">
    <div class="card mb-4">
      <div class="card-header"><strong>Personal Information</strong></div>
      <div class="card-body">
        <div class="row g-3">
          
          <div class="col-md-4">
            <label class="form-label">First Name <span class="text-danger">*</span></label>
            <input type="text" name="patient_first_name"
                   value="<?php echo e(old('patient_first_name', $patient->patient_first_name ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['patient_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <?php $__errorArgs = ['patient_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Last Name <span class="text-danger">*</span></label>
            <input type="text" name="patient_last_name"
                   value="<?php echo e(old('patient_last_name', $patient->patient_last_name ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['patient_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <?php $__errorArgs = ['patient_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Birthday</label>
            <input type="date" name="patient_birthday"
                   value="<?php echo e(old('patient_birthday', optional($patient)->patient_birthday?->format('Y-m-d'))); ?>"
                   class="form-control <?php $__errorArgs = ['patient_birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['patient_birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Sex <span class="text-danger">*</span></label>
            <select name="sex" class="form-select <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
              <option value="">Choose…</option>
              <?php $__currentLoopData = ['Male','Female']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($opt); ?>"
                  <?php echo e(old('sex', $patient->sex ?? '') === $opt ? 'selected' : ''); ?>>
                  <?php echo e($opt); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Civil Status <span class="text-danger">*</span></label>
            <select name="civil_status" class="form-select <?php $__errorArgs = ['civil_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
              <option value="">Choose…</option>
              <?php $__currentLoopData = ['Single','Married','Divorced','Widowed','Separated']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status); ?>"
                  <?php echo e(old('civil_status', $patient->civil_status ?? '') === $status ? 'selected' : ''); ?>>
                  <?php echo e($status); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['civil_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Phone Number</label>
            <div class="input-group">
              <span class="input-group-text">(+63)</span>
              <input type="text" name="phone_number"
                     value="<?php echo e(old('phone_number', $patient->phone_number ?? '')); ?>"
                     class="form-control <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-12">
            <label class="form-label">Address</label>
            <textarea name="address" rows="2"
                      class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      placeholder="Street, Barangay, City, Zip Code"><?php echo e(old('address', $patient->address ?? '')); ?></textarea>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
      </div>
      <div class="card-footer text-end">
        <button type="button" class="btn btn-primary step-next"
                data-current="personal" data-next="medical">
          Next
        </button>
      </div>
    </div>
  </div>

  
  <div class="tab-pane fade" id="medical" role="tabpanel">
    <div class="card mb-4">
      <div class="card-header"><strong>Medical Details</strong></div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-12">
            <label class="form-label">Primary Reason</label>
            <input type="text" name="primary_reason"
                   value="<?php echo e(old('primary_reason', $medical->primary_reason ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['primary_reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['primary_reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-3">
            <label class="form-label">Weight (KG)</label>
            <input type="number" step="0.1" name="weight"
                   value="<?php echo e(old('weight', $medical->weight ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-3">
            <label class="form-label">Height (cm)</label>
            <input type="number" step="0.1" name="height"
                   value="<?php echo e(old('height', $medical->height ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-3">
            <label class="form-label">Temperature (°F)</label>
            <input type="number" step="0.1" name="temperature"
                   value="<?php echo e(old('temperature', $medical->temperature ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['temperature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['temperature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-3">
            <label class="form-label">Blood Pressure</label>
            <input type="text" name="blood_pressure"
                   value="<?php echo e(old('blood_pressure', $medical->blood_pressure ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['blood_pressure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="e.g. 120/80">
            <?php $__errorArgs = ['blood_pressure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-3">
            <label class="form-label">Heart Rate (BPM)</label>
            <input type="number" name="heart_rate"
                   value="<?php echo e(old('heart_rate', $medical->heart_rate ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['heart_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['heart_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div class="col-12 mt-3">
            <label class="form-label">Medical History</label>
            <div class="row">
              <div class="col-md-3">
                <?php $__currentLoopData = ['hypertension','heart_disease','copd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox"
                           name="history_<?php echo e($h); ?>" id="history_<?php echo e($h); ?>"
                           <?php echo e(old("history_$h", $medical->{'medical_history'}[$h] ?? false) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="history_<?php echo e($h); ?>">
                      <?php echo e(ucwords(str_replace('_',' ',$h))); ?>

                    </label>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="col-md-3">
                <?php $__currentLoopData = ['diabetes','asthma','kidney_disease']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox"
                           name="history_<?php echo e($h); ?>" id="history_<?php echo e($h); ?>"
                           <?php echo e(old("history_$h", $medical->{'medical_history'}[$h] ?? false) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="history_<?php echo e($h); ?>">
                      <?php echo e(ucwords(str_replace('_',' ',$h))); ?>

                    </label>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="col-md-6">
                <label class="form-label mt-2">Others</label>
                <input type="text" name="history_others"
                       value="<?php echo e(old('history_others', $medical->{'medical_history'}['others'] ?? '')); ?>"
                       class="form-control <?php $__errorArgs = ['history_others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="Specify if not listed">
                <?php $__errorArgs = ['history_others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>

          
          <div class="col-12 mt-4">
            <label class="form-label">Allergies</label>
            <div class="row">
              <div class="col-md-3">
                <?php $__currentLoopData = ['penicillin','nsaids','contrast_dye']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox"
                           name="allergy_<?php echo e($a); ?>" id="allergy_<?php echo e($a); ?>"
                           <?php echo e(old("allergy_$a", $medical->{'allergies'}[$a] ?? false) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="allergy_<?php echo e($a); ?>">
                      <?php echo e(ucwords(str_replace('_',' ',$a))); ?>

                    </label>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="col-md-3">
                <?php $__currentLoopData = ['sulfa','latex','none']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox"
                           name="allergy_<?php echo e($a); ?>" id="allergy_<?php echo e($a); ?>"
                           <?php echo e(old("allergy_$a", $medical->{'allergies'}[$a] ?? false) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="allergy_<?php echo e($a); ?>">  
                      <?php echo e($a==='none' ? 'No Known Allergies' : ucwords($a)); ?>

                    </label>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="col-md-6">
                <label class="form-label mt-2">Others</label>
                <input type="text" name="allergy_others"
                       value="<?php echo e(old('allergy_others', $medical->{'allergies'}['others'] ?? '')); ?>"
                       class="form-control <?php $__errorArgs = ['allergy_others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="Specify if not listed">
                <?php $__errorArgs = ['allergy_others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="card-footer d-flex justify-content-between">
        <button type="button" class="btn btn-secondary step-prev"
                data-current="medical" data-prev="personal">
          Previous
        </button>
        <button type="button" class="btn btn-primary step-next"
                data-current="medical" data-next="admission">
          Next
        </button>
      </div>
    </div>
  </div>

  
  <div class="tab-pane fade" id="admission" role="tabpanel">
    <div class="card mb-4">
      <div class="card-header"><strong>Admission Details</strong></div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label">Admission Date <span class="text-danger">*</span></label>
      <input type="datetime-local"
       class="form-control"
       name="admission_date"
       value="<?php echo e(old('admission_date', now()->format('Y-m-d\TH:i'))); ?>">

            <?php $__errorArgs = ['admission_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Admission Type <span class="text-danger">*</span></label>
            <input type="text" name="admission_type"
                   value="<?php echo e(old('admission_type', $admission->admission_type ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['admission_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <?php $__errorArgs = ['admission_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Admission Source</label>
            <input type="text" name="admission_source"
                   value="<?php echo e(old('admission_source', $admission->admission_source ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['admission_source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['admission_source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Department <span class="text-danger">*</span></label>
            <select id="department" name="department_id"
                    class="form-select <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
              <option value="">Choose…</option>
              <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($d->department_id); ?>"
                  <?php echo e(old('department_id', $admission->department_id ?? '') == $d->department_id ? 'selected':''); ?>>
                  <?php echo e($d->department_name); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Attending Doctor <span class="text-danger">*</span></label>
            <select id="doctor" name="doctor_id"
                    class="form-select <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
              <option value="">Choose department first…</option>
              <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $limit = 10;
                  $load  = $doc->today_load ?? $doc->todaysLoad();
                  $full  = $load >= $limit;
                  $statusText = $full ? 'Unavailable' : 'Available';
                ?>
                <option value="<?php echo e($doc->doctor_id); ?>"
                        <?php echo e(old('doctor_id', $admission->doctor_id ?? '') == $doc->doctor_id ? 'selected' : ''); ?>

                        <?php echo e($full ? 'disabled' : ''); ?>>
                  <?php echo e($doc->doctor_name); ?> (<?php echo e($statusText); ?>)
                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['doctor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Room <span class="text-danger">*</span></label>
            <select id="room" name="room_id"
                    class="form-select <?php $__errorArgs = ['room_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
              <option value="">Choose department first…</option>
              <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $occupied = $room->occupiedCount();
                  $full     = $room->isFull();
                ?>
                <option value="<?php echo e($room->room_id); ?>"
                        <?php echo e(old('room_id', $admission->room_id ?? '') == $room->room_id ? 'selected' : ''); ?>

                        <?php echo e($full ? 'disabled' : ''); ?>>
                  <?php echo e($room->room_number); ?> (<?php echo e($occupied); ?>/<?php echo e($room->capacity); ?>)
                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['room_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Bed</label>
            <select id="bed" name="bed_id"
                    class="form-select <?php $__errorArgs = ['bed_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <option value="">Choose room first…</option>
              <?php $__currentLoopData = $beds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $occupied = $bd->isOccupied();
                  $text     = $bd->bed_number . ' (' . ($occupied ? 'Occupied' : 'Free') . ')';
                ?>
                <option value="<?php echo e($bd->bed_id); ?>"
                        <?php echo e(old('bed_id', $admission->bed_id ?? '') == $bd->bed_id ? 'selected' : ''); ?>

                        <?php echo e($occupied ? 'disabled' : ''); ?>>
                  <?php echo e($text); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['bed_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-12">
            <label class="form-label">Admission Notes</label>
            <textarea name="admission_notes" rows="3"
                      class="form-control <?php $__errorArgs = ['admission_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      placeholder="Any special instructions…"><?php echo e(old('admission_notes', $admission->admission_notes ?? '')); ?></textarea>
            <?php $__errorArgs = ['admission_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
      </div>
      <div class="card-footer d-flex justify-content-between">
        <button type="button" class="btn btn-secondary step-prev"
                data-current="admission" data-prev="medical">
          Previous
        </button>
        <button type="button" class="btn btn-primary step-next"
                data-current="admission" data-next="billing">
          Next
        </button>
      </div>
    </div>
  </div>

  
  <div class="tab-pane fade" id="billing" role="tabpanel">
    <div class="card mb-4">
      <div class="card-header"><strong>Billing Details</strong></div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Guarantor Name <span class="text-danger">*</span></label>
            <input type="text" name="guarantor_name"
                   value="<?php echo e(old('guarantor_name', optional($billing)->guarantor_name ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['guarantor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <?php $__errorArgs = ['guarantor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-6">
            <label class="form-label">Relationship to Guarantor <span class="text-danger">*</span></label>
            <input type="text" name="guarantor_relationship"
                   value="<?php echo e(old('guarantor_relationship', optional($billing)->guarantor_relationship ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['guarantor_relationship'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <?php $__errorArgs = ['guarantor_relationship'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label class="form-label">Initial Deposit (₱)</label>
            <input type="number" step="0.01" name="initial_deposit"
                   value="<?php echo e(old('initial_deposit', optional($billing)->initial_deposit ?? '')); ?>"
                   class="form-control <?php $__errorArgs = ['initial_deposit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['initial_deposit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
  <label class="form-label">Doctor Fee (₱)</label>
  <input type="text"
         class="form-control"
         value="₱<?php echo e(number_format(optional($admission)->doctor->rate ?? 0, 2)); ?>"
         readonly>
</div>

        </div>
      </div>
      <div class="card-footer">
        <button type="button" class="btn btn-secondary step-prev"
                data-current="billing" data-prev="admission">
          Previous
        </button>
        
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  // dynamic fetch logic
  const deptSelect = document.getElementById('department');
  const docSelect  = document.getElementById('doctor');
  const roomSelect = document.getElementById('room');
  const bedSelect  = document.getElementById('bed');

  deptSelect?.addEventListener('change', async () => {
    const depId = deptSelect.value;
    if (!depId) return;
    // fetch doctors
    const doctors = await fetch(`/admission/departments/${depId}/doctors`).then(r => r.json());
    docSelect.innerHTML = `<option value="">Choose doctor…</option>`;
    doctors.forEach(d => {
      docSelect.innerHTML += `<option value="${d.doctor_id}">${d.doctor_name}</option>`;
    });
    // fetch rooms
    const rooms = await fetch(`/admission/departments/${depId}/rooms`).then(r => r.json());
    roomSelect.innerHTML = `<option value="">Choose room…</option>`;
    rooms.forEach(rm => {
      roomSelect.innerHTML += `<option value="${rm.room_id}">${rm.room_number}</option>`;
    });
    // clear beds
    bedSelect.innerHTML = `<option value="">Choose room first…</option>`;
  });

  roomSelect?.addEventListener('change', async () => {
    const roomId = roomSelect.value;
    if (!roomId) return;
    const beds = await fetch(`/admission/rooms/${roomId}/beds`).then(r => r.json());
    bedSelect.innerHTML = `<option value="">Choose bed…</option>`;
    beds.forEach(b => {
      bedSelect.innerHTML += `<option value="${b.bed_id}">${b.bed_number}</option>`;
    });
  });

  // restore on edit
  if (deptSelect?.value) deptSelect.dispatchEvent(new Event('change'));
  if (roomSelect?.value) roomSelect.dispatchEvent(new Event('change'));

  // step navigation
  document.querySelectorAll('.step-next').forEach(btn => {
    btn.addEventListener('click', () => {
      const current = btn.dataset.current;
      const next    = btn.dataset.next;
      document.getElementById(`${current}-tab`).classList.add('completed');
      new bootstrap.Tab(document.getElementById(`${next}-tab`)).show();
    });
  });

  document.querySelectorAll('.step-prev').forEach(btn => {
    btn.addEventListener('click', () => {
      const current = btn.dataset.current;
      const prev    = btn.dataset.prev;
      document.getElementById(`${current}-tab`).classList.remove('completed');
      new bootstrap.Tab(document.getElementById(`${prev}-tab`)).show();
    });
  });
});
</script>
<?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/patients/_form.blade.php ENDPATH**/ ?>