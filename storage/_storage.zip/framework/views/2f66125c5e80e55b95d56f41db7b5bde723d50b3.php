


<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
  <h4 class="mb-4">Post Manual Charges</h4>

  
  <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
      <?php echo e(session('success')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul class="mb-0">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($err); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="POST" action="<?php echo e(route('billing.charges.store')); ?>">
    <?php echo csrf_field(); ?>

    
    <div class="mb-4">
      <label for="patient_id" class="form-label">Patient</label>
      <select
        id="patient_id"
        name="patient_id"
        class="form-select <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        required
      >
        <option value="">— select patient —</option>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option
            value="<?php echo e($p->patient_id); ?>"
            <?php echo e(old('patient_id') == $p->patient_id ? 'selected' : ''); ?>

          >
            <?php echo e($p->patient_last_name); ?>, <?php echo e($p->patient_first_name); ?>

            (ID: <?php echo e(str_pad($p->patient_id, 6, '0', STR_PAD_LEFT)); ?>)
          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = ['patient_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span>Charges</span>
        <button type="button" class="btn btn-sm btn-outline-primary" id="addRowBtn">
          <i class="fa-solid fa-plus me-1"></i> Add Row
        </button>
      </div>

      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table mb-0" id="chargesTable">
            <thead class="table-light">
              <tr>
                <th>Item</th>
                <th style="width: 120px;" class="text-end">Unit ₱</th>
                <th style="width: 100px;">Qty</th>
                <th style="width: 140px;" class="text-end">Subtotal ₱</th>
                <th style="width: 60px;"></th>
              </tr>
            </thead>
            <tbody>
              <?php $grouped = $services->groupBy('service_type'); ?>
              <tr class="charge-row">
                <td>
                  <select name="charges[0][service_id]"
                          class="form-select service-select <?php $__errorArgs = ['charges.0.service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          required>
                    <option value="">— select item —</option>
                    <?php $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <optgroup label="<?php echo e(ucfirst($type)); ?>">
                        <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option
                            value="<?php echo e($s->service_id); ?>"
                            data-price="<?php echo e($s->price); ?>"
                          >
                            <?php echo e($s->service_name); ?> — ₱<?php echo e(number_format($s->price,2)); ?>

                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </optgroup>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </td>
                <td class="text-end align-middle">
                  <input type="text"
                         class="form-control-plaintext unit-price"
                         readonly
                         value="₱0.00">
                </td>
                <td class="align-middle">
                  <input type="number"
                         name="charges[0][quantity]"
                         class="form-control quantity-input <?php $__errorArgs = ['charges.0.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                         min="1"
                         value="1"
                         required>
                </td>
                <td class="text-end align-middle">
                  <input type="text"
                         class="form-control-plaintext line-subtotal"
                         readonly
                         value="₱0.00">
                </td>
                <td class="text-center align-middle">
                  <button type="button" class="btn btn-sm btn-outline-danger removeRow">
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </td>
              </tr>
            </tbody>
            <tfoot class="table-light">
              <tr>
                <th colspan="3" class="text-end">Grand Total</th>
                <th class="text-end" id="grandTotal">₱0.00</th>
                <th></th>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      <div class="card-footer text-end">
        <button type="submit" class="btn btn-primary">
          <i class="fa-solid fa-paper-plane me-1"></i> Submit Charges
        </button>
        <a href="<?php echo e(route('billing.charges.index')); ?>" class="btn btn-secondary ms-2">
          Cancel
        </a>
      </div>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  let idx = 1;
  const tbody      = document.querySelector('#chargesTable tbody');
  const grandTotal = document.getElementById('grandTotal');

  document.getElementById('addRowBtn').addEventListener('click', () => {
    const row = tbody.querySelector('.charge-row').cloneNode(true);

    // update the name attributes
    row.querySelector('.service-select').name  = `charges[${idx}][service_id]`;
    row.querySelector('.quantity-input').name = `charges[${idx}][quantity]`;

    // reset values
    row.querySelector('.service-select').selectedIndex = 0;
    row.querySelector('.unit-price').value    = '₱0.00';
    row.querySelector('.quantity-input').value = 1;
    row.querySelector('.line-subtotal').value = '₱0.00';

    tbody.appendChild(row);
    idx++;
  });

  // delegate change and remove events
  tbody.addEventListener('change', e => {
    if (e.target.matches('.service-select') || e.target.matches('.quantity-input')) {
      const tr = e.target.closest('tr');
      const price = parseFloat(tr.querySelector('.service-select')
                        .selectedOptions[0]?.dataset.price || 0);
      const qty   = parseInt(tr.querySelector('.quantity-input').value) || 0;

      tr.querySelector('.unit-price').value    = `₱${price.toFixed(2)}`;
      tr.querySelector('.line-subtotal').value = `₱${(price * qty).toFixed(2)}`;
      recalc();
    }
  });

  tbody.addEventListener('click', e => {
    if (e.target.closest('.removeRow')) {
      const rows = tbody.querySelectorAll('tr');
      if (rows.length > 1) {
        e.target.closest('tr').remove();
        recalc();
      }
    }
  });

  function recalc() {
    let total = 0;
    tbody.querySelectorAll('.line-subtotal').forEach(inp => {
      total += parseFloat(inp.value.replace(/[^0-9.-]+/g,'')) || 0;
    });
    grandTotal.textContent = `₱${total.toFixed(2)}`;
  }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.billing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/billing/charges/create.blade.php ENDPATH**/ ?>