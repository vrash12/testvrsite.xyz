



<?php $__env->startSection('content'); ?>
<div class="container-fluid h-100 border p-4 d-flex flex-column" style="background-color: #fafafa;">

  
  <div class="mb-3">
    <h1 class="hdng">Patient Supply Requests Queue</h1>
    <p>Confirm request completion</p>
  </div>

  
  <form method="GET" action="<?php echo e(route('supplies.queue')); ?>">
    <div class="row mb-3 g-2">
      <div class="col-md-2">
        <button type="submit" class="btn btn-outline-primary w-100">
          <i class="fa-solid fa-filter me-2"></i>Filter
        </button>
      </div>
      <div class="col-md-2">
        <select name="status" class="form-select">
          <option value="">All Statuses</option>
          <option value="pending"   <?php echo e(request('status')=='pending'   ? 'selected' : ''); ?>>Pending</option>
          <option value="completed" <?php echo e(request('status')=='completed' ? 'selected' : ''); ?>>Completed</option>
        </select>
      </div>
      <div class="col-md-2">
        <select name="date_range" class="form-select">
          <option value="">Default</option>
          <option value="asc"  <?php echo e(request('date_range')=='asc'  ? 'selected' : ''); ?>>Oldest first</option>
          <option value="desc" <?php echo e(request('date_range')=='desc' ? 'selected' : ''); ?>>Newest first</option>
        </select>
      </div>
      <div class="col-md-6">
        <div class="input-group">
          <input type="text"
                 name="search"
                 class="form-control"
                 placeholder="Search by Name or MRN"
                 value="<?php echo e(request('search')); ?>">
          <span class="input-group-text"><i class="fas fa-search"></i></span>
        </div>
      </div>
    </div>
  </form>

  
  <div class="table-responsive flex-grow-1" style="max-height: 500px; overflow-y: auto;">
    <table class="table table-hover table-sm mb-0">
      <thead class="table-light">
        <tr>
          <th>Entry Date</th>
          <th>MRN</th>
          <th>Patient Name</th>
          <th>Item Name</th>
          <th>Quantity</th>
          <th>Assigned By</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
       <?php $__empty_1 = true; $__currentLoopData = $miscReq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
  <td><?php echo e($misc->created_at->format('Y-m-d')); ?></td>
  <td><?php echo e($misc->patient->patient_id); ?></td>
  <td><?php echo e($misc->patient->patient_first_name); ?> <?php echo e($misc->patient->patient_last_name); ?></td>
  <td><?php echo e(optional($misc->service)->service_name ?? '—'); ?></td>
  <td><?php echo e($misc->quantity); ?></td>
  <td>
  <?php echo e(optional($misc->creator)->username ?? '—'); ?>

</td>
  <td>
    <span class="badge bg-<?php echo e($misc->status==='pending'? 'warning text-dark':'success'); ?>">
      <?php echo e(ucfirst($misc->status)); ?>

    </span>
  </td>
  <td class="d-flex gap-1">
    <a href="<?php echo e(route('supplies.show', $misc->id)); ?>" class="btn btn-sm btn-outline-info">
      <i class="fa-solid fa-eye me-1"></i>View
    </a>
    <?php if($misc->status === 'pending'): ?>
      <form action="<?php echo e(route('supplies.complete', $misc->id)); ?>" method="POST" class="m-0">
        <?php echo csrf_field(); ?>
        <button class="btn btn-sm btn-outline-success">
          <i class="fa-solid fa-check me-1"></i>Confirm
        </button>
      </form>
    <?php else: ?>
      <span class="btn btn-sm btn-outline-secondary disabled">
        <i class="fa-solid fa-check-double me-1"></i>Done
      </span>
    <?php endif; ?>
  </td>
</tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="8" class="text-center text-muted py-3">
              No supply requests found.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  // (your existing SweetAlert or other JS can remain here)
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.supplies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/supplies/queue.blade.php ENDPATH**/ ?>