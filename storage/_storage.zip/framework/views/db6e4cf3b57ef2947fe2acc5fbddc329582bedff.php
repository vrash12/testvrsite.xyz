



<?php $__env->startSection('content'); ?>
<div class="container-fluid h-100 border p-4 d-flex flex-column" style="background-color: #fafafa;">

    
    <div>
        <h5 class="hdng">Laboratory Services Management</h5>
        <p class="lead">Welcome to Laboratory! Manage Lab Charges and Service Completion</p>
    </div>

    
    <div class="card mb-3">
        <div class="card-body py-4">
            <div class="row">
                <div class="col col-md-3 col-sm-6">
                    <select class="form-select">
                        <option value="">All</option>
                        <option value="pending">Pending</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <div class="col col-md-3 col-sm-6">
                    <select class="form-select">
                        <option value="">All</option>
                        <option value="pending">Pending</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <div class="col col-md-6 col-sm-12">
                    <div class="input-group w-100">
                        <input type="text" class="form-control" placeholder="Search by Name or MRN">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card" style="height: 70vh;">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0 fw-semibold">
                    <i class="fa-solid fa-users-line me-2 text-secondary"></i>Patient Queue
                </h5>
                <a href="<?php echo e(route('laboratory.queue')); ?>" class="btn btn-primary">
                    <i class="fa-solid fa-clock-rotate-left me-2"></i>Refresh
                </a>
            </div>

            <div class="table-responsive rounded shadow-sm p-1">
                <table class="table align-middle table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Date Assigned</th>
                            <th>Patient</th>
                            <th>Description</th>
                            <th>Assigned By</th>
                            <th>Status</th>
                            <th class="text-end">Amount</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $labRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
    <td>
  <?php echo e($request->created_at->format('M j, Y g:i A')); ?>

</td>


      
      <td>
        <div class="fw-semibold">
          <?php echo e($request->patient->patient_first_name); ?>

          <?php echo e($request->patient->patient_last_name); ?>

        </div>
        <small class="text-muted">
          ID: <?php echo e($request->patient->patient_id); ?>

        </small>
      </td>

      
      <td>
        <?php echo e($request->service->description
           ?? $request->service->service_name); ?>

      </td>

      
      <td>
        <?php echo e($request->doctor->doctor_name ?? 'N/A'); ?>

      </td>

      
      <td>
        <span
          class="badge <?php echo e($request->service_status === 'pending'
                     ? 'bg-warning text-dark'
                     : 'bg-success text-white'); ?>">
          <?php echo e(ucfirst($request->service_status)); ?>

        </span>
      </td>

      
      <td class="text-end">
        ₱<?php echo e(number_format($request->amount, 2)); ?>

      </td>

      
   <td class="text-center">
  <?php if($request->service_status === 'pending'): ?>
    <a href="<?php echo e(route('laboratory.details', $request)); ?>"
       class="btn btn-sm btn-outline-secondary">
      <i class="fa-solid fa-file-circle-question me-1"></i>
      Details
    </a>
  <?php else: ?>
    <span class="text-muted">Completed</span>
  <?php endif; ?>
</td>

    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
      <td colspan="7" class="text-center text-muted py-3">
        <i class="fa-solid fa-puzzle-piece me-2"></i>No Data Available
      </td>
    </tr>
  <?php endif; ?>
</tbody>

                </table>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('.confirm-btn');

    buttons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();

            const row = btn.closest('tr');

            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#00529A",
                cancelButtonColor: "#d33",
                confirmButtonText: "Confirm"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Update status badge
                    const badge = row.querySelector('.badge');
                    badge.classList.remove('bg-warning', 'text-dark');
                    badge.classList.add('bg-success', 'text-white');
                    badge.textContent = 'Completed';

                    // Remove button
                    btn.remove();

                    Swal.fire({
                        title: "Confirmed",
                        text: "Request marked as completed.",
                        icon: "success"
                    });

                    // Optionally: AJAX call to update status in DB here
                }
            });
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.laboratory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/laboratory/queue.blade.php ENDPATH**/ ?>