2


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3">Manage Users</h1>
    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success">
      <i class="fas fa-plus"></i> New User
    </a>
  </div>

  <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <table class="table table-bordered">
    <thead class="table-light">
      <tr>
        <th>#</th><th>Username</th><th>Email</th><th>Role</th><th width="150">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($u->user_id); ?></td>
          <td><?php echo e($u->username); ?></td>
          <td><?php echo e($u->email); ?></td>
          <td><?php echo e(ucfirst($u->role)); ?></td>
          <td>
            <a href="<?php echo e(route('admin.users.edit',$u)); ?>" class="btn btn-sm btn-outline-secondary">✎</a>
        
            <form method="POST" action="<?php echo e(route('admin.users.destroy',$u)); ?>" class="d-inline">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button onclick="return confirm('Delete?')" class="btn btn-sm btn-outline-danger">🗑</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/admin/users/index.blade.php ENDPATH**/ ?>