

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
  <h1 class="h4 mb-3">Add New Laboratory Charge</h1>

  
  <form method="POST" action="<?php echo e(route('laboratory.store')); ?>" id="lab-form">
    <?php echo $__env->make('laboratory._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      

    
    <div class="text-end">
      <a href="<?php echo e(route('laboratory.dashboard')); ?>" class="btn btn-secondary">Cancel</a>
      <button type="submit" class="btn btn-primary">Create Charge</button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.laboratory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/laboratory/create.blade.php ENDPATH**/ ?>