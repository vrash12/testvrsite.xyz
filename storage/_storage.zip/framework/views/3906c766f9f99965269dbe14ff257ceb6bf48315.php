



<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
  <h4 class="mb-4">Audit Trail for Charge #<?php echo e($item->billing_item_id); ?></h4>

  <?php if($item->logs->isEmpty()): ?>
    <div class="alert alert-secondary">
      No audit records found for this charge.
    </div>
  <?php else: ?>
    <ul class="timeline list-unstyled">
      <?php $__currentLoopData = $item->logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="timeline-item mb-4 pb-2 border-bottom">
          <div class="d-flex align-items-center mb-1">
            <i class="fa-solid <?php echo e($log->icon); ?> fa-lg text-primary me-3"></i>
            <div>
              <strong><?php echo e($log->action); ?></strong>
              <div class="small text-muted">
                <?php echo e($log->created_at->format('Y-m-d H:i')); ?> by <?php echo e($log->actor); ?>

              </div>
            </div>
          </div>
          <p class="mb-0"><?php echo e($log->message); ?></p>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php endif; ?>

  <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary mt-3">
    <i class="fa-solid fa-arrow-left me-1"></i> Back
  </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.billing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/billing/charges/audit.blade.php ENDPATH**/ ?>