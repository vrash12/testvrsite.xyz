


<?php $__env->startSection('content'); ?>
<div class="container-fluid min-vh-100 p-4 d-flex flex-column" style="background-color: #fafafa;">

  <!-- Header -->
  <header class="mb-3">
    <h4 class="hdng">Patient Billing Management</h4>
    <p class="text-muted mb-0">Manage patient billing records and disputes.</p>
  </header>

  <!-- Metrics -->
  <div class="row g-3 mb-4">
    <div class="col-lg-3 col-md-6">
      <div class="card border">
        <div class="card-body d-flex align-items-center">
          <div class="me-3"><i class="fa-solid fa-chart-simple fa-2x text-secondary"></i></div>
          <div>
            <div class="text-muted small">Total Revenue</div>
            <h5 class="mb-0">₱<?php echo e(number_format($totalRevenue, 2)); ?></h5>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="card border">
        <div class="card-body d-flex align-items-center">
          <div class="me-3"><i class="fa-solid fa-peso-sign fa-2x text-secondary"></i></div>
          <div>
            <div class="text-muted small">Outstanding Balance</div>
            <h5 class="mb-0">₱<?php echo e(number_format($outstandingBalance, 2)); ?></h5>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="card border">
        <div class="card-body d-flex align-items-center">
          <div class="me-3"><i class="fa-solid fa-bed fa-2x text-secondary"></i></div>
          <div>
            <div class="text-muted small">Active Patients</div>
            <h5 class="mb-0"><?php echo e($activePatients); ?></h5>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3 col-md-6">
      <div class="card border">
        <div class="card-body d-flex align-items-center">
          <div class="me-3"><i class="fa-solid fa-person-circle-question fa-2x text-secondary"></i></div>
          <div>
            <div class="text-muted small">Pending Disputes</div>
            <h5 class="mb-0"><?php echo e($pendingDisputes); ?></h5>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Recent Billing Items -->
  <div class="card mb-5 flex-grow-1">
    <div class="card-body d-flex flex-column">
      <h5 class="fw-semibold mb-3">
        <i class="fa-solid fa-calendar-plus me-2 text-primary"></i>
        Recent Billing Activity
      </h5>

      <div class="table-responsive rounded shadow-sm p-2 overflow-auto">
        <table class="table table-hover mb-0 align-middle">
          <thead class="table-light">
            <tr>
              <th>MRN</th>
              <th>Patient</th>
              <th>Description</th>
              <th>Origin</th>
              <th class="text-end">Amount</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $recentBillItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php
                $p    = optional($item->bill->patient);
                $svc  = optional($item->service);
                $dept = optional($svc->department);
              ?>
              <tr>
                <td><?php echo e($p->patient_id ?? '—'); ?></td>
                <td><?php echo e(trim(($p->patient_first_name ?? '').' '.($p->patient_last_name ?? '')) ?: '—'); ?></td>
                <td><?php echo e($svc->service_name ?? 'N/A'); ?></td>
                <td>
                  <span class="badge bg-info">
                    <?php echo e($dept->department_name ?? '—'); ?>

                  </span>
                </td>
                <td class="text-end">
                  ₱<?php echo e(number_format($item->amount - ($item->discount_amount ?? 0), 2)); ?>

                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="5" class="text-center text-muted py-3">
                  No recent billing activity.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
          <?php if($recentBillItems->isNotEmpty()): ?>
            <tfoot>
              <tr class="fw-semibold">
                <td colspan="4" class="text-end">Subtotal</td>
                <td class="text-end">₱<?php echo e(number_format($billItemsTotal,2)); ?></td>
              </tr>
            </tfoot>
          <?php endif; ?>
        </table>
      </div>
    </div>
  </div>

  <!-- Recent Service Assignments -->
  <div class="card flex-grow-1">
    <div class="card-body d-flex flex-column">
      <h5 class="fw-semibold mb-3">
        <i class="fa-solid fa-tools me-2 text-primary"></i>
        Recent Service Assignments
      </h5>

      <div class="table-responsive rounded shadow-sm p-2 overflow-auto">
        <table class="table table-hover mb-0 align-middle">
          <thead class="table-light">
            <tr>
              <th>MRN</th>
              <th>Patient</th>
              <th>Service</th>
              <th>Dept.</th>
              <th class="text-end">Price</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $recentServiceAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php
                $p    = optional($sa->patient);
                $svc  = optional($sa->service);
                $dept = optional($svc->department);
              ?>
              <tr>
                <td><?php echo e($p->patient_id ?? '—'); ?></td>
                <td><?php echo e(trim(($p->patient_first_name ?? '').' '.($p->patient_last_name ?? '')) ?: '—'); ?></td>
                <td><?php echo e($svc->service_name ?? 'N/A'); ?></td>
                <td><?php echo e($dept->department_name ?? '—'); ?></td>
                <td class="text-end">₱<?php echo e(number_format($svc->price ?? 0,2)); ?></td>
                <td>
                  <span class="badge bg-<?php echo e($sa->service_status==='confirmed'?'success':'secondary'); ?>">
                    <?php echo e(ucfirst($sa->service_status)); ?>

                  </span>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="6" class="text-center text-muted py-3">
                  No recent services.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
          <?php if($recentServiceAssignments->isNotEmpty()): ?>
            <tfoot>
              <tr class="fw-semibold">
                <td colspan="4" class="text-end">Subtotal</td>
                <td class="text-end">₱<?php echo e(number_format($servicesTotal,2)); ?></td>
                <td></td>
              </tr>
            </tfoot>
          <?php endif; ?>
        </table>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.billing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/billing/dashboard.blade.php ENDPATH**/ ?>