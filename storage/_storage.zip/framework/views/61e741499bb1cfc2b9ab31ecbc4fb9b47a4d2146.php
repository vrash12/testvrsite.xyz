

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h3 class="fw-bold text-primary mb-3">Patients With Orders</h3>

    <div class="row g-3">
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="card h-100 shadow-sm patient-card"
                     data-bs-toggle="modal"
                     data-bs-target="#patientModal"
                     data-id="<?php echo e($p->patient_id); ?>"
                     data-name="<?php echo e($p->patient_first_name); ?> <?php echo e($p->patient_last_name); ?>">
                    <div class="card-body d-flex align-items-center">
                        <div class="rounded-circle bg-light me-3" style="width:60px;height:60px;"></div>
                        <div>
                            <div class="fw-semibold"><?php echo e($p->patient_first_name); ?> <?php echo e($p->patient_last_name); ?></div>
                            <small class="text-muted">P-<?php echo e($p->patient_id); ?></small><br>
                     <span class="badge bg-primary">
  <?php echo e($p->service_assignments_count + $p->prescriptions_count); ?> Orders
</span>

                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-4"><?php echo e($patients->links()); ?></div>
</div>

<div class="modal fade" id="patientModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="modalTitle" class="fw-bold mb-0"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="modalBody">
                <p class="text-muted">Loading…</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const baseUrl = "<?php echo e(url('/doctor/orders')); ?>/";   // ➜ "/doctor/orders/"

  document.querySelectorAll('.patient-card').forEach(card => {
    card.addEventListener('click', e => {
      const id   = e.currentTarget.dataset.id
      const name = e.currentTarget.dataset.name
      document.getElementById('modalTitle').textContent =
        `${name} (P-${id})`

      document.getElementById('modalBody').innerHTML =
        '<p class="text-muted">Loading…</p>';

      fetch(baseUrl + id)                       // ← matches the route above
        .then(r => r.text())
        .then(html => document.getElementById('modalBody').innerHTML = html)
        .catch(() => {
          document.getElementById('modalBody').innerHTML =
            '<p class="text-danger">Unable to load orders.</p>';
        });
    });
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php if(session('show_patient')): ?>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const pid   = "<?php echo e(session('show_patient')); ?>";
  const card  = document.querySelector(`.patient-card[data-id='${pid}']`);
  if (card) card.click();   // triggers the same fetch + modal open
});
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>



<?php echo $__env->make('layouts.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/doctor/orders-index.blade.php ENDPATH**/ ?>