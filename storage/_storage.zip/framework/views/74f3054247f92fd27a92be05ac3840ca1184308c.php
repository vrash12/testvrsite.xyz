
<div id="charge-trace-timeline">
  <ul class="list-group mb-3">
    <?php $__empty_1 = true; $__currentLoopData = $charge->logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <li class="list-group-item">
        <span class="badge bg-secondary rounded-circle me-2">
          <?php echo e(strtoupper(substr($log->action,0,1))); ?>

        </span>
        <?php echo e(ucfirst($log->action)); ?> –
        <?php echo e($charge->service?->service_name ?? '—'); ?>

        <div class="small text-muted">
          <?php echo e($log->created_at->format('Y-m-d H:i')); ?>

          by <?php echo e($log->actor ?? 'System'); ?>

        </div>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <li class="list-group-item text-center text-muted">
        <em>No trace records found.</em>
      </li>
    <?php endif; ?>
  </ul>
</div>


<div id="charge-trace-details">
  <table class="table table-sm">
      <tr><th>Description</th><td><?php echo e($charge->service?->service_name ?? '—'); ?></td></tr>
      <tr><th>ID</th><td><?php echo e($charge->billing_item_id); ?></td></tr>
      <tr><th>Amount</th><td>₱<?php echo e(number_format($charge->amount,2)); ?></td></tr>
      <tr><th>Status</th><td class="text-capitalize"><?php echo e($charge->status); ?></td></tr>
      <tr><th>Department</th>
          <td><?php echo e($charge->service?->department?->department_name ?? '—'); ?></td></tr>
      <tr><th>Date</th>
          <td><?php echo e($charge->billing_date?->format('Y-m-d') ?? '—'); ?></td></tr>
  </table>
</div>
<?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/patient/billing/chargeTrace.blade.php ENDPATH**/ ?>