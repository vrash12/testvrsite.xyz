

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
  <h4 class="mb-3">Settle / Discharge Patients</h4>

  
  <form method="GET" action="<?php echo e(route('billing.discharge.index')); ?>"
        class="row g-2 mb-4 align-items-end">
    <div class="col-auto">
      <label class="form-label small mb-1">Search</label>
      <input type="text" name="search"
             value="<?php echo e(request('search')); ?>"
             class="form-control form-control-sm"
             placeholder="MRN or Name">
    </div>
    <div class="col-auto">
      <label class="form-label small mb-1">Sort by</label>
      <select name="sort_by" class="form-select form-select-sm">
        <option value="patient_id"        <?php if(request('sort_by')=='patient_id'): echo 'selected'; endif; ?>       >MRN</option>
        <option value="patient_last_name" <?php if(request('sort_by')=='patient_last_name'): echo 'selected'; endif; ?>>Name</option>
        <option value="balance"           <?php if(request('sort_by')=='balance'): echo 'selected'; endif; ?>          >Outstanding</option>
      </select>
    </div>
    <div class="col-auto">
      <label class="form-label small mb-1">Direction</label>
      <select name="sort_dir" class="form-select form-select-sm">
        <option value="asc"  <?php if(request('sort_dir')=='asc'): echo 'selected'; endif; ?> >Asc</option>
        <option value="desc" <?php if(request('sort_dir')=='desc'): echo 'selected'; endif; ?>>Desc</option>
      </select>
    </div>
    <div class="col-auto">
      <button class="btn btn-primary btn-sm">Apply</button>
    </div>
  </form>

  
  <div class="table-responsive rounded shadow-sm">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr>
          <th>MRN</th>
          <th>Name</th>
          <th class="text-end">Outstanding ₱</th>
          <th class="text-center">Action</th>
        </tr>
      </thead>
      <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $modalId = 'depositModal-'.$p->patient_id; ?>

        <tr>
          <td><?php echo e(str_pad($p->patient_id,8,'0',STR_PAD_LEFT)); ?></td>
          <td><?php echo e($p->patient_first_name); ?> <?php echo e($p->patient_last_name); ?></td>
          <td class="text-end"><?php echo e(number_format($p->balance,2)); ?></td>
          <td class="text-center">
            
            <button class="btn btn-outline-secondary btn-sm me-1"
                    data-bs-toggle="modal" data-bs-target="#<?php echo e($modalId); ?>">
              <i class="fa-solid fa-clock-rotate-left me-1"></i> History
            </button>

            <?php if($p->balance == 0): ?>
              
            <form method="POST" action="<?php echo e(route('billing.discharge.settle', $p->patient_id)); ?>"
                    class="d-inline">
                <?php echo csrf_field(); ?>
                <button class="btn btn-success btn-sm">
                  <i class="fa-solid fa-circle-check me-1"></i> Settle
                </button>
              </form>
            <?php else: ?>
              
              <button class="btn btn-primary btn-sm"
                      data-bs-toggle="modal" data-bs-target="#<?php echo e($modalId); ?>">
                <i class="fa-solid fa-money-bill-wave me-1"></i> Deposit
              </button>
            <?php endif; ?>
          </td>
        </tr>

        
        <?php $__env->startPush('modals'); ?>
          <div class="modal fade" id="<?php echo e($modalId); ?>" tabindex="-1"
               aria-labelledby="<?php echo e($modalId); ?>Label" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
              <div class="modal-content">
                <form method="POST" action="<?php echo e(route('billing.deposits.store')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="patient_id" value="<?php echo e($p->patient_id); ?>">

                  <div class="modal-header">
                    <h5 class="modal-title" id="<?php echo e($modalId); ?>Label">
                      Deposits – <?php echo e($p->patient_first_name); ?> <?php echo e($p->patient_last_name); ?>

                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>

                  <div class="modal-body">
                    
                    <div class="row g-3 mb-4">
                      <div class="col-md-6">
                        <label class="form-label">Amount (₱)</label>
                        <input type="number" name="amount" step="0.01" min="0"
                               class="form-control" required autofocus>
                      </div>
                      <div class="col-md-6">
                        <label class="form-label">Deposit Date</label>
                        <input type="date" name="deposited_at"
                               class="form-control"
                               value="<?php echo e(now()->toDateString()); ?>" required>
                      </div>
                    </div>

                    
                    <h6 class="fw-semibold mb-2">Last 5 Deposits</h6>
                    <div class="table-responsive rounded shadow-sm">
                      <table class="table table-sm table-bordered mb-0">
                        <thead class="table-light">
                          <tr><th>Date</th><th class="text-end">Amount ₱</th></tr>
                        </thead>
                        <tbody>
                          <?php $__empty_2 = true; $__currentLoopData = $p->deposits->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <tr>
                              <td><?php echo e($d->deposited_at->format('Y-m-d')); ?></td>
                              <td class="text-end"><?php echo e(number_format($d->amount,2)); ?></td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <tr>
                              <td colspan="2" class="text-center text-muted">No deposits yet.</td>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div class="modal-footer">
                    <button class="btn btn-primary">Save Deposit</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                      Close
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        <?php $__env->stopPush(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="4" class="text-center py-3 text-muted">No active patients.</td>
        </tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  
  <div class="mt-3">
    <?php echo e($patients->links()); ?>

  </div>
</div>


<?php echo $__env->yieldPushContent('modals'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.billing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/billing/discharge/index.blade.php ENDPATH**/ ?>