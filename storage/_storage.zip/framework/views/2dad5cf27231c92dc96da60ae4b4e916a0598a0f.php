


<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

  
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb bg-white px-3 py-2 rounded shadow-sm mb-4">
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('laboratory.dashboard')); ?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item">
        <a href="<?php echo e(route('laboratory.queue')); ?>">Queue</a>
      </li>
      <li class="breadcrumb-item active" aria-current="page">
        Request #<?php echo e($assignment->assignment_id); ?>

      </li>
    </ol>
  </nav>

  
  <div class="card shadow-sm">
    <div class="card-header bg-primary text-white d-flex justify-content-between">
      <h5 class="mb-0">
        <i class="fa-solid fa-vial me-2"></i>
        Lab Request Details
      </h5>
      <a href="<?php echo e(route('laboratory.queue')); ?>" class="btn btn-light btn-sm">
        <i class="fa-solid fa-arrow-left me-1"></i> Back to Queue
      </a>
    </div>

    <div class="card-body">
      <dl class="row">
        <dt class="col-sm-3">Assignment ID</dt>
        <dd class="col-sm-9">#<?php echo e($assignment->assignment_id); ?></dd>

        <dt class="col-sm-3">Patient</dt>
        <dd class="col-sm-9">
          <?php echo e(optional($assignment->patient)->patient_first_name ?? '—'); ?>

          <?php echo e(optional($assignment->patient)->patient_last_name  ?? ''); ?>

          <br>
          <small class="text-muted">
            ID: <?php echo e(optional($assignment->patient)->patient_id ?? '—'); ?>

          </small>
        </dd>

        <dt class="col-sm-3">Doctor</dt>
        <dd class="col-sm-9">
          <?php echo e(optional($assignment->doctor)->doctor_name ?? '—'); ?>

        </dd>

        <dt class="col-sm-3">Service</dt>
        <dd class="col-sm-9">
          <?php echo e(optional($assignment->service)->service_name ?? '—'); ?>

          <small class="text-muted">
            (<?php echo e(optional($assignment->service->department)->department_name ?? '—'); ?>)
          </small>
        </dd>

        <dt class="col-sm-3">Description</dt>
        <dd class="col-sm-9">
          <?php echo e(optional($assignment->service)->description ?? '—'); ?>

        </dd>

        <dt class="col-sm-3">Date Assigned</dt>
        <dd class="col-sm-9">
          
         <?php echo e(optional($assignment->created_at)->format('M j, Y g:i A') ?? '—'); ?>


        </dd>

        <dt class="col-sm-3">Amount</dt>
        <dd class="col-sm-9">
          ₱<?php echo e(number_format($assignment->amount, 2)); ?>

        </dd>
      </dl>
    </div>

    <div class="card-footer bg-white text-end">
      <?php if($assignment->service_status === 'pending'): ?>
        <form action="<?php echo e(route('laboratory.details.complete', $assignment)); ?>"
              method="POST" class="d-inline">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-success">
            <i class="fa-solid fa-check me-1"></i>
            Mark as Completed
          </button>
        </form>
      <?php else: ?>
        <span class="badge bg-success text-white">Completed</span>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.laboratory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/laboratory/details.blade.php ENDPATH**/ ?>