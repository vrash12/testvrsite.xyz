



<?php $__env->startSection('content'); ?>
<div class="container-fluid h-100 border p-4 d-flex flex-column" style="background-color: #fafafa;">

    
    <div>
        <h5 class="hdng">Operating Room Services Management</h5>
        <p class="lead">Manage OR Charges and Service Completion</p>
    </div>

    
    <div class="card mb-3">
        <div class="card-body py-4">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <select id="status-filter" class="form-select">
                        <option value="">All Statuses</option>
                        <option value="pending">Pending</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <div class="col-md-3 col-sm-6">
                    <select id="or-filter" class="form-select">
                        <option value="">All OR Nos.</option>
                        <?php $__currentLoopData = $procedures->pluck('room')->unique()->filter()->sort(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orNo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($orNo); ?>">OR <?php echo e($orNo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="input-group w-100">
                        <input type="text" id="search-input" class="form-control" placeholder="Search by Name or MRN">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card" style="height: 70vh;">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0 fw-semibold">
                    <i class="fa-solid fa-procedures me-2 text-secondary"></i>OR Queue
                </h5>
                <a href="<?php echo e(route('operating.queue')); ?>" class="btn btn-primary">
                    <i class="fa-solid fa-clock-rotate-left me-2"></i>Refresh
                </a>
            </div>

            <div class="table-responsive rounded shadow-sm p-1">
                <table class="table align-middle table-hover mb-0" id="or-queue-table">
                    <thead class="table-light">
                        <tr>
                            <th>Date Assigned</th>
                            <th>Patient</th>
                            <th>Procedure</th>
                            <th>OR No.</th>
                            <th>Assigned By</th>
                            <th>Status</th>
                            <th class="text-end">Amount</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $procedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr data-status="<?php echo e($procedure->service_status); ?>" data-or="<?php echo e($procedure->room); ?>" data-name="<?php echo e(strtolower($procedure->patient->patient_first_name.' '.$procedure->patient->patient_last_name)); ?>" data-mrn="<?php echo e($procedure->patient->patient_id); ?>">
                   <td>
    <?php echo e(optional($procedure->created_at)->format('M j, Y g:i A') ?? '–'); ?>

</td>

                            <td>
                                <div class="fw-semibold">
                                    <?php echo e($procedure->patient->patient_first_name); ?>

                                    <?php echo e($procedure->patient->patient_last_name); ?>

                                </div>
                                <small class="text-muted">P-<?php echo e($procedure->patient->patient_id); ?></small>
                            </td>
                            <td><?php echo e($procedure->service->description ?? $procedure->service->service_name); ?></td>
                            <td><?php echo e($procedure->room ?? '–'); ?></td>
                            <td><?php echo e($procedure->doctor->doctor_name ?? 'N/A'); ?></td>
                            <td>
                                <span class="badge <?php echo e($procedure->service_status === 'pending'
                                           ? 'bg-warning text-dark'
                                           : 'bg-success text-white'); ?>">
                                    <?php echo e(ucfirst($procedure->service_status)); ?>

                                </span>
                            </td>
                            <td class="text-end">₱<?php echo e(number_format($procedure->amount, 2)); ?></td>
                            <td class="text-center">
                                <a href="#" class="btn btn-sm btn-success add-charge-btn"
   data-bs-toggle="modal"
   data-bs-target="#addChargeModal"
   data-patient-id="<?php echo e($procedure->patient->patient_id); ?>"
   data-patient-name="<?php echo e($procedure->patient->patient_first_name); ?> <?php echo e($procedure->patient->patient_last_name); ?>">
   <i class="fa-solid fa-plus me-1"></i>Add Charge
</a>

                                <?php if($procedure->service_status === 'pending'): ?>
                                    <a href="<?php echo e(route('operating.details', $procedure)); ?>"
                                       class="btn btn-sm btn-outline-secondary confirm-btn">
                                        <i class="fa-solid fa-file-circle-question me-1"></i>
                                        Details
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">Completed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-3">
                                <i class="fa-solid fa-puzzle-piece me-2"></i>No Data Available
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-3 d-flex justify-content-center">
  <?php echo e($procedures->links()); ?>

</div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    // Confirmation for marking completed
    document.querySelectorAll('.confirm-btn').forEach(btn => {
        btn.addEventListener('click', e => {
            e.preventDefault();
            const row = btn.closest('tr');
            Swal.fire({
                title: "Mark this procedure complete?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#00529A",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, complete it"
            }).then(result => {
                if (result.isConfirmed) {
                    // Update badge
                    const badge = row.querySelector('.badge');
                    badge.classList.remove('bg-warning','text-dark');
                    badge.classList.add('bg-success','text-white');
                    badge.textContent = 'Completed';
                    // Remove button
                    btn.remove();
                    Swal.fire("Completed!", "Procedure has been marked completed.", "success");
                    // TODO: AJAX call to update DB
                }
            });
        });
    });

    // Client-side filtering
    const statusFilter = document.getElementById('status-filter');
    const orFilter     = document.getElementById('or-filter');
    const searchInput  = document.getElementById('search-input');
    const tableRows    = document.querySelectorAll('#or-queue-table tbody tr');

    function applyFilters() {
        const statusVal = statusFilter.value;
        const orVal     = orFilter.value.toLowerCase();
        const searchVal = searchInput.value.toLowerCase();

        tableRows.forEach(row => {
            const matchesStatus = !statusVal || row.dataset.status === statusVal;
            const matchesOr     = !orVal     || row.dataset.or === orVal.replace('or ', '');
            const matchesSearch = !searchVal || row.dataset.name.includes(searchVal) || row.dataset.mrn.includes(searchVal);
            row.style.display = (matchesStatus && matchesOr && matchesSearch) ? '' : 'none';
        });
    }

    statusFilter.addEventListener('change', applyFilters);
    orFilter.addEventListener('change', applyFilters);
    searchInput.addEventListener('input', applyFilters);
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.operatingroom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/operatingroom/queue.blade.php ENDPATH**/ ?>