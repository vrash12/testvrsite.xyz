


<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <h1 class="h4 mb-3">Hello, <?php echo e($user->username); ?>!</h1>
    <p>Welcome to your patient portal! A hub for patients to access medical records and bills anytime, anywhere.</p>

    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Patient ID</h5>
                    <p class="card-text"><?php echo e(str_pad($user->patient_id, 8, '0', STR_PAD_LEFT)); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Room Number</h5>
                    <p class="card-text"><?php echo e($admission->room_number ?? 'N/A'); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Latest Admit Date</h5>
                    <p class="card-text">
                        <?php echo e($admission && $admission->admission_date
                            ? $admission->admission_date->format('m/d/Y')
                            : 'N/A'); ?>

                    </p>
                </div>
            </div>
        </div>

    <div class="col-md-3 mb-4">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title">Amount Due</h5>

          
          <p class="mb-1">
            <small class="text-muted">Services & Pharmacy:</small><br>
            ₱<?php echo e(number_format($servicesSubtotal, 2)); ?>

          </p>

          
          <p class="mb-1">
            <small class="text-muted">Bed / Room Rate:</small><br>
            ₱<?php echo e(number_format($resourceRate, 2)); ?>

          </p>

          
          <p class="mb-1">
            <small class="text-muted">Doctor Fee:</small><br>
            ₱<?php echo e(number_format($doctorRate, 2)); ?>

          </p>

          <hr class="my-2"/>

          
          <div class="fs-5 fw-bold">
            ₱<?php echo e(number_format($amountDue, 2)); ?>

          </div>
        </div>
      </div>



    </div>

    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Prescriptions to Take</h5>
                    <?php $__empty_1 = true; $__currentLoopData = $prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="mb-2">
                            <strong><?php echo e($item->service->service_name); ?></strong>
                            — <?php echo e($item->dosage ?? 'Qty: '.$item->quantity_asked); ?>

                            <br>
                            <small class="text-muted">
                                Ordered on
                                <?php echo e(\Carbon\Carbon::parse($item->datetime)->format('m/d/Y h:i A')); ?>

                            </small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No prescriptions</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Your Schedule Today</h5>
                    <?php $__empty_1 = true; $__currentLoopData = $todaySchedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sched): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="mb-2">
                            <strong><?php echo e($sched->service->service_name); ?></strong>
                            at <?php echo e(\Carbon\Carbon::parse($sched->datetime)->format('h:i A')); ?>

                            <br>
                            <small class="text-muted"><?php echo e(ucfirst($sched->service_status)); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No appointments</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Assigned Doctors</h5>
                    <?php $__empty_1 = true; $__currentLoopData = $assignedDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <p>
                            <?php echo e($doc->doctor_name); ?>

                            (<?php echo e($doc->doctor_specialization); ?>)
                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No doctors assigned</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Pharmacy Charges</h5>
                    <?php $__empty_1 = true; $__currentLoopData = $pharmacyCharges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="mb-2">
                            <strong><?php echo e($c->service->service_name); ?></strong>
                            — ₱<?php echo e(number_format($c->quantity_asked * $c->service->price, 2)); ?>

                            <br>
                            <small class="text-muted">
                                Ordered on
                                <?php echo e(\Carbon\Carbon::parse($c->datetime)->format('m/d/Y h:i A')); ?>

                            </small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No charges</p>
                    <?php endif; ?>

                    <hr/>
                    <p class="mb-0">
                        <strong>Total Pharmacy Charges:</strong>
                        ₱<?php echo e(number_format($pharmacyTotal, 2)); ?>

                    </p>
                </div>
            </div>
        </div>

        <div class="card mb-3 shadow-sm">
          <div class="card-header bg-light fw-semibold">
            Hospital Services <span class="badge bg-primary"><?php echo e($serviceAssignments->count()); ?></span>
          </div>
          <div class="card-body p-0">
            <?php if($serviceAssignments->isEmpty()): ?>
                <p class="text-muted p-3 mb-0">No services ordered yet.</p>
            <?php else: ?>
              <table class="table table-sm mb-0">
                <thead>
                  <tr>
                    <th>Datetime</th>
                    <th>Service</th>
                    <th>Dept.</th>
                    <th class="text-end">Price</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $serviceAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e(\Carbon\Carbon::parse($sa->datetime)->format('M d, Y')); ?></td>
                      <td><?php echo e($sa->service->service_name); ?></td>
                      <td><?php echo e($sa->service->department->department_name ?? '—'); ?></td>
                      <td class="text-end"><?php echo e(number_format($sa->service->price, 2)); ?></td>
                      <td>
                        <span class="badge bg-<?php echo e($sa->service_status === 'confirmed' ? 'success' : 'secondary'); ?>">
                          <?php echo e(ucfirst($sa->service_status)); ?>

                        </span>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                  <tr class="fw-semibold">
                    <td colspan="3" class="text-end">Total</td>
                    <td class="text-end"><?php echo e(number_format($servicesTotal, 2)); ?></td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            <?php endif; ?>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.patients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u423903798/domains/testvrsite.xyz/resources/views/patient/dashboard.blade.php ENDPATH**/ ?>